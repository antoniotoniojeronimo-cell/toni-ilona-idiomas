package com.toniilona.app

import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.*
import java.util.Locale
import kotlin.math.abs

private data class Challenge(
    val es: String,
    val en: String,
    val category: String,
    val level: Int,
    val type: String
)

class MainActivity : AppCompatActivity(), TextToSpeech.OnInitListener {
    private val dbUrl = "https://toni-ilona-idiomas-default-rtdb.europe-west1.firebasedatabase.app"
    private lateinit var auth: FirebaseAuth
    private lateinit var db: FirebaseDatabase
    private lateinit var tts: TextToSpeech

    private var role = ""
    private var room = ""
    private var myUid = ""
    private var round = 0
    private var level = 1
    private var toniScore = 0
    private var ilonaScore = 0
    private var toniStreak = 0
    private var ilonaStreak = 0
    private var turnRole = "TONI"
    private var toniMember = false
    private var ilonaMember = false
    private var toniOnline = false
    private var ilonaOnline = false
    private var lastRenderedRound = -1
    private var lastAnswerRound = -1
    private var roomListener: ValueEventListener? = null
    private var presenceListener: ValueEventListener? = null

    private lateinit var status: TextView
    private lateinit var roomInfo: TextView
    private lateinit var score: TextView
    private lateinit var category: TextView
    private lateinit var question: TextView
    private lateinit var answers: LinearLayout
    private lateinit var feedback: TextView
    private lateinit var next: Button
    private lateinit var end: Button
    private lateinit var rolePanel: LinearLayout
    private lateinit var roomPanel: LinearLayout
    private lateinit var code: EditText

    private val bank: List<Challenge> by lazy { buildBank() }

    override fun onCreate(state: Bundle?) {
        super.onCreate(state)
        setContentView(R.layout.activity_main)
        bindViews()
        auth = FirebaseAuth.getInstance()
        db = FirebaseDatabase.getInstance(dbUrl)
        tts = TextToSpeech(this, this)

        auth.signInAnonymously()
            .addOnSuccessListener {
                myUid = auth.currentUser?.uid.orEmpty()
                status.text = "🟢 Conectado. Elige quién juega."
            }
            .addOnFailureListener { status.text = "⚠️ No se pudo conectar: ${it.message}" }

        findViewById<Button>(R.id.toniButton).setOnClickListener { chooseRole("TONI") }
        findViewById<Button>(R.id.ilonaButton).setOnClickListener { chooseRole("ILONA") }
        findViewById<Button>(R.id.createButton).setOnClickListener { createRoom() }
        findViewById<Button>(R.id.joinButton).setOnClickListener { joinRoom() }
        next.setOnClickListener { renderRoom() }
        end.setOnClickListener { finishGame() }
    }

    private fun bindViews() {
        status = findViewById(R.id.status)
        roomInfo = findViewById(R.id.roomInfo)
        score = findViewById(R.id.score)
        category = findViewById(R.id.category)
        question = findViewById(R.id.question)
        answers = findViewById(R.id.answers)
        feedback = findViewById(R.id.feedback)
        next = findViewById(R.id.nextButton)
        end = findViewById(R.id.endButton)
        rolePanel = findViewById(R.id.rolePanel)
        roomPanel = findViewById(R.id.roomPanel)
        code = findViewById(R.id.roomCode)
    }

    private fun chooseRole(value: String) {
        role = value
        status.text = if (role == "TONI") {
            "TONI 🇪🇸 → 🇬🇧 Inglés"
        } else {
            "ILONA 🇱🇻 → 🇪🇸 Español\nLatviski: tu mācies spāņu valodu."
        }
        rolePanel.visibility = View.GONE
        roomPanel.visibility = View.VISIBLE
        code.visibility = View.VISIBLE
        findViewById<Button>(R.id.createButton).visibility = if (role == "TONI") View.VISIBLE else View.GONE
        findViewById<Button>(R.id.joinButton).visibility = if (role == "ILONA") View.VISIBLE else View.GONE
    }

    private fun newCode(): String {
        val chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"
        return (1..6).map { chars.random() }.joinToString("")
    }

    private fun roomRef(): DatabaseReference = db.reference.child("rooms").child(room)
    private fun myPresenceRef(): DatabaseReference = db.reference.child("presence").child(myUid)

    private fun createRoom() {
        if (auth.currentUser == null || myUid.isBlank()) {
            status.text = "Conectando…"
            return
        }
        room = newCode()
        val roomData = mapOf(
            "active" to true,
            "round" to 0,
            "turnRole" to "TONI",
            "challengeIndex" to 0,
            "toniScore" to 0,
            "ilonaScore" to 0,
            "toniStreak" to 0,
            "ilonaStreak" to 0,
            "level" to 1,
            "lastAnswerRound" to -1,
            "lastAnswerPlayer" to "",
            "lastAnswerCorrect" to false,
            "lastAnswerText" to "",
            "members" to mapOf("toniUid" to myUid, "ilonaUid" to "")
        )
        roomRef().setValue(roomData)
            .addOnSuccessListener {
                registerPresence()
                listenToRoom()
                status.text = "🟢 Sala creada. Comparte el código con Ilona."
                roomInfo.text = "SALA $room"
            }
            .addOnFailureListener { status.text = "❌ ${it.message}" }
    }

    private fun joinRoom() {
        if (auth.currentUser == null || myUid.isBlank()) {
            status.text = "Conectando…"
            return
        }
        room = code.text.toString().trim().uppercase(Locale.getDefault())
        if (room.length != 6) {
            status.text = "Escribe un código de 6 caracteres."
            return
        }
        roomRef().get().addOnSuccessListener { snap ->
            if (!snap.exists()) {
                status.text = "❌ No existe esa sala."
                return@addOnSuccessListener
            }
            if (snap.child("active").getValue(Boolean::class.java) == false) {
                status.text = "❌ Esa partida ya terminó."
                return@addOnSuccessListener
            }
            val hostUid = snap.child("members").child("toniUid").getValue(String::class.java).orEmpty()
            if (hostUid.isBlank()) {
                status.text = "❌ La sala no está preparada."
                return@addOnSuccessListener
            }
            val currentIlona = snap.child("members").child("ilonaUid").getValue(String::class.java).orEmpty()
            if (currentIlona.isNotBlank() && currentIlona != myUid) {
                status.text = "❌ Esta sala ya tiene una Ilona conectada."
                return@addOnSuccessListener
            }
            roomRef().child("members").child("ilonaUid").setValue(myUid)
                .addOnSuccessListener {
                    registerPresence()
                    listenToRoom()
                    status.text = "🟢 Unido a la sala."
                    roomInfo.text = "SALA $room"
                }
                .addOnFailureListener { status.text = "❌ ${it.message}" }
        }.addOnFailureListener { status.text = "❌ ${it.message}" }
    }

    private fun registerPresence() {
        if (myUid.isBlank()) return
        // Presence is informational only. Room membership is the authoritative
        // synchronization signal, so a transient presence event can never
        // block the game or make one phone wait forever.
        myPresenceRef().onDisconnect().setValue(false)
        myPresenceRef().setValue(true)
    }

    private fun listenToRoom() {
        roomListener?.let { roomRef().removeEventListener(it) }
        roomListener = object : ValueEventListener {
            override fun onCancelled(error: DatabaseError) {
                status.text = "⚠️ Conexión temporalmente perdida. Firebase reintentará automáticamente."
            }

            override fun onDataChange(s: DataSnapshot) {
                round = s.child("round").getValue(Int::class.java) ?: 0
                turnRole = s.child("turnRole").getValue(String::class.java) ?: if (round % 2 == 0) "TONI" else "ILONA"
                toniScore = s.child("toniScore").getValue(Int::class.java) ?: 0
                ilonaScore = s.child("ilonaScore").getValue(Int::class.java) ?: 0
                toniStreak = s.child("toniStreak").getValue(Int::class.java) ?: 0
                ilonaStreak = s.child("ilonaStreak").getValue(Int::class.java) ?: 0
                level = (s.child("level").getValue(Int::class.java) ?: 1).coerceIn(1, 5)
                val hostUid = s.child("members").child("toniUid").getValue(String::class.java).orEmpty()
                val guestUid = s.child("members").child("ilonaUid").getValue(String::class.java).orEmpty()
                toniMember = hostUid.isNotBlank()
                ilonaMember = guestUid.isNotBlank()
                lastAnswerRound = s.child("lastAnswerRound").getValue(Int::class.java) ?: -1
                updateScore()
                updateConnectionLabels()
                if (s.child("active").getValue(Boolean::class.java) == false) showFinished() else renderRoom(s)
            }
        }
        roomRef().addValueEventListener(roomListener!!)
    }

    private fun updateConnectionLabels() {
        if (room.isBlank()) return
        val toniState = if (toniMember) "🟢 conectado" else "⚪ esperando"
        val ilonaState = if (ilonaMember) "🟢 conectada" else "⚪ esperando"
        roomInfo.text = "SALA $room\nTONI $toniState   •   ILONA $ilonaState"
    }

    private fun updateScore() {
        score.text = "TONI 🇬🇧 $toniScore  •  ILONA 🇪🇸 $ilonaScore\n🔥 $toniStreak / $ilonaStreak   •   Nivel $level   •   ♾️"
    }

    private fun challengeFor(index: Int): Challenge = bank[index.mod(bank.size)]

    private fun renderRoom(snapshot: DataSnapshot? = null) {
        end.visibility = View.VISIBLE
        next.visibility = View.GONE
        val bothJoined = toniMember && ilonaMember
        if (!bothJoined) {
            category.text = "❤️ Preparando partida"
            question.text = "Comparte el código de sala con el otro jugador."
            answers.removeAllViews()
            feedback.text = "Cuando aparezcan TONI 🟢 e ILONA 🟢, empezará la partida."
            status.text = if (role == "TONI") "Esperando a Ilona…" else "Conectada. Esperando a Toni…"
            return
        }

        val index = snapshot?.child("challengeIndex")?.getValue(Int::class.java) ?: (round * 17 + level * 3).mod(bank.size)
        val c = challengeFor(index)
        category.text = "${c.category} • Nivel ${c.level} • Ronda ${round + 1}"
        updateConnectionLabels()

        val lastPlayer = snapshot?.child("lastAnswerPlayer")?.getValue(String::class.java).orEmpty()
        val lastCorrect = snapshot?.child("lastAnswerCorrect")?.getValue(Boolean::class.java) ?: false
        val lastText = snapshot?.child("lastAnswerText")?.getValue(String::class.java).orEmpty()
        if (lastPlayer.isNotBlank() && lastAnswerRound == round - 1) {
            feedback.text = if (lastCorrect) "🎉 ${if (lastPlayer == "TONI") "Toni" else "Ilona"} acertó: $lastText" else "💡 ${if (lastPlayer == "TONI") "Toni" else "Ilona"}: $lastText"
        }

        if (turnRole != role) {
            status.text = "👀 Turno de ${if (turnRole == "TONI") "TONI" else "ILONA"}"
            question.text = if (turnRole == "ILONA") {
                "👀 ILONA está practicando español 🇪🇸\n\n🇬🇧 ${c.en}\n➡️ 🇪🇸 ${c.es}"
            } else {
                "👀 TONI está practicando inglés 🇬🇧\n\n🇪🇸 ${c.es}\n➡️ 🇬🇧 ${c.en}"
            }
            answers.removeAllViews()
            next.visibility = View.GONE
            return
        }

        status.text = "🎮 ¡Es tu turno!"
        val prompt = if (role == "TONI") "🇪🇸 ${c.es}\n\n👉 Elige la frase correcta en inglés 🇬🇧" else "🇬🇧 ${c.en}\n\n👉 Elige la frase correcta en español 🇪🇸"
        question.text = prompt
        showOptions(c, round)
    }

    private fun showOptions(c: Challenge, seed: Int) {
        answers.removeAllViews()
        val correct = if (role == "TONI") c.en else c.es
        val candidates = bank.filter { it != c && it.level <= (level + 1) }
            .map { if (role == "TONI") it.en else it.es }
            .filter { it != correct }
            .distinct()
            .shuffled()
            .take(3)
            .toMutableList()
        while (candidates.size < 3) {
            candidates.add(correct)
        }
        val options = (candidates + correct).distinct().shuffled()
        options.forEach { value ->
            Button(this).apply {
                text = value
                isAllCaps = false
                minHeight = 56
                setOnClickListener { submitAnswer(value, c) }
                answers.addView(this)
            }
        }
        feedback.text = ""
    }

    private fun submitAnswer(value: String, c: Challenge) {
        if (turnRole != role || !(toniMember && ilonaMember)) return
        val correctAnswer = if (role == "TONI") c.en else c.es
        val isCorrect = value == correctAnswer
        val expectedRound = round
        val nextRole = if (role == "TONI") "ILONA" else "TONI"
        val nextIndex = chooseNextIndex(expectedRound, c)
        val room = roomRef()

        room.runTransaction(object : Transaction.Handler {
            override fun doTransaction(current: MutableData): Transaction.Result {
                val active = current.child("active").getValue(Boolean::class.java) ?: true
                val currentRound = current.child("round").getValue(Int::class.java) ?: 0
                val currentTurn = current.child("turnRole").getValue(String::class.java) ?: "TONI"
                if (!active || currentRound != expectedRound || currentTurn != role) return Transaction.abort()

                val ts = System.currentTimeMillis()
                current.child("round").value = currentRound + 1
                current.child("turnRole").value = nextRole
                current.child("challengeIndex").value = nextIndex
                current.child("lastAnswerRound").value = currentRound
                current.child("lastAnswerPlayer").value = role
                current.child("lastAnswerCorrect").value = isCorrect
                current.child("lastAnswerText").value = value
                current.child("lastAnswerAt").value = ts

                val tScore = current.child("toniScore").getValue(Int::class.java) ?: 0
                val iScore = current.child("ilonaScore").getValue(Int::class.java) ?: 0
                val tStreak = current.child("toniStreak").getValue(Int::class.java) ?: 0
                val iStreak = current.child("ilonaStreak").getValue(Int::class.java) ?: 0
                if (role == "TONI") {
                    current.child("toniScore").value = tScore + if (isCorrect) 1 else 0
                    current.child("toniStreak").value = if (isCorrect) tStreak + 1 else 0
                } else {
                    current.child("ilonaScore").value = iScore + if (isCorrect) 1 else 0
                    current.child("ilonaStreak").value = if (isCorrect) iStreak + 1 else 0
                }
                val total = (tScore + if (role == "TONI" && isCorrect) 1 else 0) + (iScore + if (role == "ILONA" && isCorrect) 1 else 0)
                current.child("level").value = (1 + total / 10).coerceAtMost(5)
                return Transaction.success(current)
            }

            override fun onComplete(error: DatabaseError?, committed: Boolean, snapshot: DataSnapshot?) {
                if (error != null) {
                    feedback.text = "⚠️ No se pudo guardar la respuesta. Inténtalo otra vez."
                    return
                }
                if (!committed) {
                    feedback.text = "⏳ El otro móvil ya ha avanzado la partida."
                    return
                }
                speak(correctAnswer, if (role == "TONI") Locale.ENGLISH else Locale("es", "ES"))
            }
        })
    }

    private fun chooseNextIndex(currentRound: Int, current: Challenge): Int {
        val levelPool = bank.indices.filter { bank[it].level <= level.coerceAtMost(5) }
        if (levelPool.isEmpty()) return (currentRound + 1).mod(bank.size)
        var candidate = abs((currentRound + 1) * 7919 + current.category.hashCode() * 31 + current.level * 101) % levelPool.size
        val idx = levelPool[candidate]
        if (idx == bank.indexOf(current)) candidate = (candidate + 1) % levelPool.size
        return levelPool[candidate]
    }

    private fun speak(text: String, locale: Locale) {
        tts.language = locale
        tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "answer")
    }

    private fun finishGame() {
        if (room.isNotBlank()) {
            roomRef().child("active").setValue(false)
        }
    }

    private fun showFinished() {
        category.text = "❤️ Partida terminada"
        question.text = "¡Buen trabajo!"
        answers.removeAllViews()
        feedback.text = "TONI $toniScore  •  ILONA $ilonaScore"
        next.visibility = View.GONE
        end.visibility = View.GONE
    }

    override fun onInit(statusCode: Int) {
        if (statusCode == TextToSpeech.SUCCESS) tts.language = Locale("es", "ES")
    }

    override fun onDestroy() {
        roomListener?.let { if (room.isNotBlank()) roomRef().removeEventListener(it) }
        if (myUid.isNotBlank()) myPresenceRef().setValue(false)
        if (::tts.isInitialized) tts.shutdown()
        super.onDestroy()
    }

    private fun buildBank(): List<Challenge> {
        val raw = listOf(
            "Hola.|Hello.|Supervivencia|1",
            "Adiós.|Goodbye.|Supervivencia|1",
            "Por favor.|Please.|Supervivencia|1",
            "Gracias.|Thank you.|Supervivencia|1",
            "De nada.|You’re welcome.|Supervivencia|1",
            "Perdón.|Sorry.|Supervivencia|1",
            "Sí.|Yes.|Supervivencia|1",
            "No.|No.|Supervivencia|1",
            "Vale.|Okay.|Supervivencia|1",
            "Buenos días.|Good morning.|Supervivencia|1",
            "Buenas tardes.|Good afternoon.|Supervivencia|1",
            "Buenas noches.|Good night.|Supervivencia|1",
            "¿Cómo estás?|How are you?|Supervivencia|1",
            "Estoy bien.|I’m fine.|Supervivencia|1",
            "Estoy cansado.|I’m tired.|Supervivencia|1",
            "Estoy cansada.|I’m tired.|Supervivencia|1",
            "Tengo hambre.|I’m hungry.|Supervivencia|1",
            "Tengo sed.|I’m thirsty.|Supervivencia|1",
            "Tengo sueño.|I’m sleepy.|Supervivencia|1",
            "No entiendo.|I don’t understand.|Supervivencia|1",
            "Entiendo.|I understand.|Supervivencia|1",
            "¿Puedes repetir?|Can you repeat?|Supervivencia|1",
            "Más despacio, por favor.|More slowly, please.|Supervivencia|1",
            "¿Qué significa?|What does it mean?|Supervivencia|1",
            "¿Cómo se dice?|How do you say it?|Supervivencia|1",
            "No lo sé.|I don’t know.|Supervivencia|1",
            "Necesito ayuda.|I need help.|Supervivencia|1",
            "¿Hablas inglés?|Do you speak English?|Supervivencia|1",
            "Estoy aprendiendo inglés.|I’m learning English.|Supervivencia|1",
            "¿Hablas español?|Do you speak Spanish?|Supervivencia|1",
            "Estoy aprendiendo español.|I’m learning Spanish.|Supervivencia|1",
            "Hasta luego.|See you later.|Supervivencia|1",
            "Nos vemos.|See you.|Supervivencia|1",
            "Mucho gusto.|Nice to meet you.|Supervivencia|1",
            "¿Puedes ayudarme?|Can you help me?|Supervivencia|1",
            "¿Dónde vives?|Where do you live?|Vida cotidiana|2",
            "Vivo en España.|I live in Spain.|Vida cotidiana|2",
            "¿De dónde eres?|Where are you from?|Vida cotidiana|2",
            "Soy de España.|I’m from Spain.|Vida cotidiana|2",
            "¿Qué haces?|What are you doing?|Vida cotidiana|2",
            "Estoy trabajando.|I’m working.|Vida cotidiana|2",
            "Estoy estudiando.|I’m studying.|Vida cotidiana|2",
            "Estoy en casa.|I’m at home.|Vida cotidiana|2",
            "Estoy fuera.|I’m outside.|Vida cotidiana|2",
            "Ahora estoy ocupado.|I’m busy right now.|Vida cotidiana|2",
            "Ahora estoy libre.|I’m free right now.|Vida cotidiana|2",
            "Tengo tiempo.|I have time.|Vida cotidiana|2",
            "No tengo tiempo.|I don’t have time.|Vida cotidiana|2",
            "Hace frío.|It’s cold.|Vida cotidiana|2",
            "Hace calor.|It’s hot.|Vida cotidiana|2",
            "Está lloviendo.|It’s raining.|Vida cotidiana|2",
            "Me gusta esto.|I like this.|Vida cotidiana|2",
            "No me gusta.|I don’t like it.|Vida cotidiana|2",
            "Me encanta.|I love it.|Vida cotidiana|2",
            "No me importa.|I don’t mind.|Vida cotidiana|2",
            "¿Qué quieres?|What do you want?|Vida cotidiana|2",
            "Quiero agua.|I want water.|Vida cotidiana|2",
            "Quiero comer.|I want to eat.|Vida cotidiana|2",
            "Quiero dormir.|I want to sleep.|Vida cotidiana|2",
            "¿Dónde está el baño?|Where is the bathroom?|Vida cotidiana|2",
            "Estoy listo.|I’m ready.|Vida cotidiana|2",
            "Espera un momento.|Wait a moment.|Vida cotidiana|2",
            "Vamos.|Let’s go.|Vida cotidiana|2",
            "Estoy en la cocina.|I’m in the kitchen.|Vida cotidiana|2",
            "Estoy en el salón.|I’m in the living room.|Vida cotidiana|2",
            "Tengo frío.|I’m cold.|Vida cotidiana|2",
            "Tengo calor.|I’m hot.|Vida cotidiana|2",
            "Estoy feliz.|I’m happy.|Vida cotidiana|2",
            "Estoy triste.|I’m sad.|Vida cotidiana|2",
            "Estoy nervioso.|I’m nervous.|Vida cotidiana|2",
            "Estoy tranquilo.|I’m calm.|Vida cotidiana|2",
            "Estoy ocupado ahora.|I’m busy now.|Vida cotidiana|2",
            "¿Qué hora es?|What time is it?|Vida cotidiana|2",
            "Es muy temprano.|It’s very early.|Vida cotidiana|2",
            "Es muy tarde.|It’s very late.|Vida cotidiana|2",
            "Te quiero.|I love you.|Pareja|3",
            "Te echo de menos.|I miss you.|Pareja|3",
            "Tengo ganas de verte.|I can’t wait to see you.|Pareja|3",
            "Quiero estar contigo.|I want to be with you.|Pareja|3",
            "¿Me llamas luego?|Will you call me later?|Pareja|3",
            "Escríbeme cuando llegues.|Text me when you arrive.|Pareja|3",
            "¿Estás bien?|Are you okay?|Pareja|3",
            "Estoy preocupado.|I’m worried.|Pareja|3",
            "Estoy preocupada.|I’m worried.|Pareja|3",
            "Estoy contento.|I’m happy.|Pareja|3",
            "Estoy contenta.|I’m happy.|Pareja|3",
            "Estoy enfadado.|I’m angry.|Pareja|3",
            "Estoy enfadada.|I’m angry.|Pareja|3",
            "Estoy aburrido.|I’m bored.|Pareja|3",
            "Estoy aburrida.|I’m bored.|Pareja|3",
            "Me haces reír.|You make me laugh.|Pareja|3",
            "Eres muy divertido.|You’re very funny.|Pareja|3",
            "Eres muy divertida.|You’re very funny.|Pareja|3",
            "Te necesito.|I need you.|Pareja|3",
            "Estoy pensando en ti.|I’m thinking about you.|Pareja|3",
            "¿Quieres un abrazo?|Do you want a hug?|Pareja|3",
            "Dame un beso.|Give me a kiss.|Pareja|3",
            "Tengo una sorpresa para ti.|I have a surprise for you.|Pareja|3",
            "Vamos a ver una película.|Let’s watch a movie.|Pareja|3",
            "Quiero pasar tiempo contigo.|I want to spend time with you.|Pareja|3",
            "¿Qué quieres hacer hoy?|What do you want to do today?|Pareja|3",
            "¿Qué hacemos esta noche?|What are we doing tonight?|Pareja|3",
            "Me gusta estar contigo.|I like being with you.|Pareja|3",
            "Estoy aquí para ti.|I’m here for you.|Pareja|3",
            "No te preocupes.|Don’t worry.|Pareja|3",
            "Tengo una idea.|I have an idea.|Conversación|3",
            "¿Qué opinas?|What do you think?|Conversación|3",
            "Estoy de acuerdo.|I agree.|Conversación|3",
            "No estoy de acuerdo.|I disagree.|Conversación|3",
            "Tienes razón.|You’re right.|Conversación|3",
            "No pasa nada.|It’s okay.|Conversación|3",
            "Claro que sí.|Of course.|Conversación|3",
            "Depende.|It depends.|Conversación|3",
            "¿Por qué?|Why?|Conversación|3",
            "Porque sí.|Because I want to.|Conversación|3",
            "¿Qué prefieres?|What do you prefer?|Conversación|3",
            "Prefiero esto.|I prefer this.|Conversación|3",
            "¿Qué te gusta hacer?|What do you like doing?|Conversación|3",
            "Me gusta viajar.|I like travelling.|Conversación|3",
            "Me gusta cocinar.|I like cooking.|Conversación|3",
            "Me gusta escuchar música.|I like listening to music.|Conversación|3",
            "Me gusta ver películas.|I like watching movies.|Conversación|3",
            "¿Cuál es tu comida favorita?|What is your favourite food?|Conversación|3",
            "Mi comida favorita es la pizza.|My favourite food is pizza.|Conversación|3",
            "¿Qué quieres aprender?|What do you want to learn?|Conversación|3",
            "Quiero hablar contigo.|I want to talk to you.|Conversación|3",
            "¿Puedes hablar más despacio?|Can you speak more slowly?|Conversación|3",
            "¿Puedes decirlo otra vez?|Can you say it again?|Conversación|3",
            "¿Cómo se pronuncia?|How do you pronounce it?|Conversación|3",
            "Estoy intentando aprender.|I’m trying to learn.|Conversación|3",
            "Cada día entiendo un poco más.|Every day I understand a little more.|Conversación|3",
            "No estoy seguro.|I’m not sure.|Conversación|3",
            "Creo que sí.|I think so.|Conversación|3",
            "Creo que no.|I don’t think so.|Conversación|3",
            "En mi opinión…|In my opinion…|Conversación|3",
            "¿Qué quieres decir?|What do you mean?|Conversación|3",
            "Déjame pensarlo.|Let me think about it.|Conversación|3",
            "Tiene sentido.|That makes sense.|Conversación|3",
            "No tiene sentido.|That doesn’t make sense.|Conversación|3",
            "Una mesa para dos, por favor.|A table for two, please.|Restaurante|3",
            "Quiero un café.|I want a coffee.|Restaurante|3",
            "Quiero agua, por favor.|I want water, please.|Restaurante|3",
            "La cuenta, por favor.|The bill, please.|Restaurante|3",
            "¿Qué me recomiendas?|What do you recommend?|Restaurante|3",
            "¿Tiene esto carne?|Does this have meat?|Restaurante|3",
            "Soy vegetariano.|I’m vegetarian.|Restaurante|3",
            "Soy vegetariana.|I’m vegetarian.|Restaurante|3",
            "Sin cebolla, por favor.|No onion, please.|Restaurante|3",
            "Sin picante, por favor.|Not spicy, please.|Restaurante|3",
            "¿Tiene esto gluten?|Does this contain gluten?|Restaurante|3",
            "Está delicioso.|It’s delicious.|Restaurante|3",
            "Está muy bueno.|It’s very good.|Restaurante|3",
            "No me gusta mucho.|I don’t like it very much.|Restaurante|3",
            "¿Podemos pedir ahora?|Can we order now?|Restaurante|3",
            "¿Nos puede traer la cuenta?|Can you bring us the bill?|Restaurante|3",
            "Quiero el mismo.|I want the same one.|Restaurante|3",
            "¿Qué lleva esto?|What is in this?|Restaurante|3",
            "¿Hay una opción vegetariana?|Is there a vegetarian option?|Restaurante|3",
            "¿Podemos sentarnos aquí?|Can we sit here?|Restaurante|3",
            "¿Cuánto cuesta?|How much is it?|Compras|3",
            "Es demasiado caro.|It’s too expensive.|Compras|3",
            "¿Tiene una talla más grande?|Do you have a larger size?|Compras|3",
            "¿Tiene una talla más pequeña?|Do you have a smaller size?|Compras|3",
            "Solo estoy mirando.|I’m just looking.|Compras|3",
            "Quiero comprar esto.|I want to buy this.|Compras|3",
            "¿Puedo probármelo?|Can I try it on?|Compras|3",
            "¿Tiene otro color?|Do you have another colour?|Compras|3",
            "Me gusta este.|I like this one.|Compras|3",
            "No me gusta ese.|I don’t like that one.|Compras|3",
            "¿Puedo pagar con tarjeta?|Can I pay by card?|Compras|3",
            "¿Tiene cambio?|Do you have change?|Compras|3",
            "Quiero devolver esto.|I want to return this.|Compras|3",
            "Necesito una bolsa.|I need a bag.|Compras|3",
            "¿Dónde están los probadores?|Where are the fitting rooms?|Compras|3",
            "¿Dónde está la estación?|Where is the station?|Viajes|4",
            "¿Dónde está el hotel?|Where is the hotel?|Viajes|4",
            "Tenemos una reserva.|We have a reservation.|Viajes|4",
            "¿A qué hora sale el tren?|What time does the train leave?|Viajes|4",
            "¿Cuánto tarda?|How long does it take?|Viajes|4",
            "Necesito un taxi.|I need a taxi.|Viajes|4",
            "¿Puedes ayudarme con la maleta?|Can you help me with the suitcase?|Viajes|4",
            "Hemos perdido el autobús.|We’ve missed the bus.|Viajes|4",
            "¿Hay Wi-Fi?|Is there Wi-Fi?|Viajes|4",
            "¿Puedes hacerme una foto?|Can you take a photo of me?|Viajes|4",
            "¿Dónde podemos comer?|Where can we eat?|Viajes|4",
            "Quiero visitar el centro.|I want to visit the city centre.|Viajes|4",
            "¿Está lejos?|Is it far?|Viajes|4",
            "¿Está cerca?|Is it nearby?|Viajes|4",
            "¿Cómo llegamos allí?|How do we get there?|Viajes|4",
            "Necesitamos dos billetes.|We need two tickets.|Viajes|4",
            "¿A qué hora abre?|What time does it open?|Viajes|4",
            "¿A qué hora cierra?|What time does it close?|Viajes|4",
            "Hemos llegado.|We’ve arrived.|Viajes|4",
            "¿Dónde podemos aparcar?|Where can we park?|Viajes|4",
            "¿Puedes indicarme el camino?|Can you show me the way?|Viajes|4",
            "Estoy perdido.|I’m lost.|Viajes|4",
            "Estoy perdida.|I’m lost.|Viajes|4",
            "Necesitamos ayuda.|We need help.|Viajes|4",
            "Nos vemos a las ocho.|See you at eight.|Planes|4",
            "Llegaré tarde.|I’ll be late.|Planes|4",
            "Estoy llegando.|I’m on my way.|Planes|4",
            "Estoy casi listo.|I’m almost ready.|Planes|4",
            "Estoy casi lista.|I’m almost ready.|Planes|4",
            "¿Puedes esperar cinco minutos?|Can you wait five minutes?|Planes|4",
            "Vamos a salir.|We’re going out.|Planes|4",
            "Quedémonos en casa.|Let’s stay at home.|Planes|4",
            "Mañana tengo trabajo.|I have work tomorrow.|Planes|4",
            "¿Qué planes tienes?|What plans do you have?|Planes|4",
            "Podemos hacerlo mañana.|We can do it tomorrow.|Planes|4",
            "Me parece bien.|Sounds good to me.|Planes|4",
            "¿A qué hora quedamos?|What time shall we meet?|Planes|4",
            "Nos encontramos allí.|We’ll meet there.|Planes|4",
            "Te aviso luego.|I’ll let you know later.|Planes|4",
            "No puedo hoy.|I can’t today.|Planes|4",
            "Puedo mañana.|I can tomorrow.|Planes|4",
            "Tengo que irme.|I have to go.|Planes|4",
            "Vuelvo enseguida.|I’ll be right back.|Planes|4",
            "Nos quedamos aquí.|We’ll stay here.|Planes|4",
            "Necesito descansar.|I need to rest.|Casa y necesidades|4",
            "Necesito dormir.|I need to sleep.|Casa y necesidades|4",
            "Necesito una ducha.|I need a shower.|Casa y necesidades|4",
            "Tengo que limpiar.|I have to clean.|Casa y necesidades|4",
            "Voy a cocinar.|I’m going to cook.|Casa y necesidades|4",
            "¿Puedes abrir la ventana?|Can you open the window?|Casa y necesidades|4",
            "¿Puedes cerrar la puerta?|Can you close the door?|Casa y necesidades|4",
            "¿Dónde están las llaves?|Where are the keys?|Casa y necesidades|4",
            "He perdido las llaves.|I’ve lost the keys.|Casa y necesidades|4",
            "Mi teléfono no funciona.|My phone doesn’t work.|Casa y necesidades|4",
            "Necesito cargar el teléfono.|I need to charge my phone.|Casa y necesidades|4",
            "No hay agua caliente.|There is no hot water.|Casa y necesidades|4",
            "La comida está lista.|The food is ready.|Casa y necesidades|4",
            "La cena está lista.|Dinner is ready.|Casa y necesidades|4",
            "Tengo que hacer la compra.|I have to go shopping.|Casa y necesidades|4",
            "¿Qué necesitamos comprar?|What do we need to buy?|Casa y necesidades|4",
            "Voy a lavar la ropa.|I’m going to do the laundry.|Casa y necesidades|4",
            "La casa está limpia.|The house is clean.|Casa y necesidades|4",
            "Estoy en el dormitorio.|I’m in the bedroom.|Casa y necesidades|4",
            "Ven aquí, por favor.|Come here, please.|Casa y necesidades|4",
            "Tengo una reunión.|I have a meeting.|Trabajo y estudio|5",
            "Estoy trabajando ahora.|I’m working now.|Trabajo y estudio|5",
            "Te llamo después.|I’ll call you later.|Trabajo y estudio|5",
            "Envíame un mensaje.|Send me a message.|Trabajo y estudio|5",
            "Necesito cinco minutos.|I need five minutes.|Trabajo y estudio|5",
            "Tengo mucho trabajo.|I have a lot of work.|Trabajo y estudio|5",
            "Necesito un descanso.|I need a break.|Trabajo y estudio|5",
            "Termino a las cinco.|I finish at five.|Trabajo y estudio|5",
            "Empezamos a las nueve.|We start at nine.|Trabajo y estudio|5",
            "¿Puedes esperar?|Can you wait?|Trabajo y estudio|5",
            "Ya terminé.|I’m finished.|Trabajo y estudio|5",
            "Estoy estudiando para un examen.|I’m studying for an exam.|Trabajo y estudio|5",
            "No entiendo esta palabra.|I don’t understand this word.|Trabajo y estudio|5",
            "¿Puedes explicármelo?|Can you explain it to me?|Trabajo y estudio|5",
            "Necesito practicar más.|I need to practise more.|Trabajo y estudio|5",
            "¿Puedes corregirme?|Can you correct me?|Trabajo y estudio|5",
            "¿Cómo se escribe?|How do you spell it?|Trabajo y estudio|5",
            "¿Qué significa esta palabra?|What does this word mean?|Trabajo y estudio|5",
            "Quiero mejorar mi inglés.|I want to improve my English.|Trabajo y estudio|5",
            "Quiero mejorar mi español.|I want to improve my Spanish.|Trabajo y estudio|5",
            "Me duele la cabeza.|I have a headache.|Salud y emergencias|5",
            "Me duele el estómago.|My stomach hurts.|Salud y emergencias|5",
            "No me siento bien.|I don’t feel well.|Salud y emergencias|5",
            "Necesito un médico.|I need a doctor.|Salud y emergencias|5",
            "Necesito una farmacia.|I need a pharmacy.|Salud y emergencias|5",
            "¿Dónde está el hospital?|Where is the hospital?|Salud y emergencias|5",
            "¿Tienes agua?|Do you have water?|Salud y emergencias|5",
            "Necesito descansar.|I need to rest.|Salud y emergencias|5",
            "Estoy mejor.|I’m better.|Salud y emergencias|5",
            "Necesito ayuda ahora.|I need help now.|Salud y emergencias|5",
            "Llama a una ambulancia.|Call an ambulance.|Salud y emergencias|5",
            "¿Dónde está la policía?|Where is the police station?|Salud y emergencias|5",
            "Mi gato habla inglés.|My cat speaks English.|Humor|2",
            "Mi perro quiere pizza.|My dog wants pizza.|Humor|2",
            "Hay un pato en la cocina.|There is a duck in the kitchen.|Humor|2",
            "El pingüino está en el hotel.|The penguin is at the hotel.|Humor|2",
            "He perdido mis zapatos.|I’ve lost my shoes.|Humor|2",
            "Mi café me está mirando.|My coffee is looking at me.|Humor|2",
            "El perro conduce el coche.|The dog is driving the car.|Humor|2",
            "Necesito un millón de pizzas.|I need a million pizzas.|Humor|2",
            "Hoy me caso con una tostadora.|Today I’m marrying a toaster.|Humor|2",
            "Mi gato cree que es el jefe.|My cat thinks it’s the boss.|Humor|2"
        )
        return raw.map { line ->
            val p = line.split("|")
            Challenge(p[0], p[1], p[2], p[3].toInt(), "multiple_choice")
        }
    }
}
