package com.toniilona.app

import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.*
import java.util.Locale

data class Challenge(
    val es: String,
    val en: String,
    val category: String,
    val level: Int,
    val esOptions: List<String>,
    val enOptions: List<String>
)

class MainActivity : AppCompatActivity(), TextToSpeech.OnInitListener {
    private val dbUrl = "https://toni-ilona-idiomas-default-rtdb.europe-west1.firebasedatabase.app"
    private lateinit var auth: FirebaseAuth
    private lateinit var db: DatabaseReference
    private lateinit var tts: TextToSpeech

    private var role = ""
    private var room = ""
    private var round = 0
    private var level = 1
    private var toniScore = 0
    private var ilonaScore = 0
    private var toniStreak = 0
    private var ilonaStreak = 0
    private var turnRole = "TONI"
    private var toniOnline = false
    private var ilonaOnline = false
    private var answered = false
    private var listener: ValueEventListener? = null

    private lateinit var status: TextView
    private lateinit var roomInfo: TextView
    private lateinit var score: TextView
    private lateinit var mode: TextView
    private lateinit var question: TextView
    private lateinit var answers: LinearLayout
    private lateinit var feedback: TextView
    private lateinit var next: Button
    private lateinit var end: Button
    private lateinit var rolePanel: LinearLayout
    private lateinit var roomPanel: LinearLayout
    private lateinit var code: EditText

    private val bank = listOf(
        Challenge("Hola.","Hello.","Supervivencia",1,listOf("Hola.","Adiós.","No.").distinct(),listOf("Hello.","Thank you.","Good afternoon.").distinct()),
        Challenge("Adiós.","Goodbye.","Supervivencia",1,listOf("Adiós.","Por favor.","Vale.").distinct(),listOf("Goodbye.","You're welcome.","Good night.").distinct()),
        Challenge("Por favor.","Please.","Supervivencia",1,listOf("Por favor.","Gracias.","Hasta luego.").distinct(),listOf("Please.","Sorry.","How are you?").distinct()),
        Challenge("Gracias.","Thank you.","Supervivencia",1,listOf("Gracias.","De nada.","Buenos días.").distinct(),listOf("Thank you.","Yes.","I'm fine.").distinct()),
        Challenge("De nada.","You're welcome.","Supervivencia",1,listOf("De nada.","Perdón.","Buenas tardes.").distinct(),listOf("You're welcome.","No.","I'm tired.").distinct()),
        Challenge("Perdón.","Sorry.","Supervivencia",1,listOf("Perdón.","Sí.","Buenas noches.").distinct(),listOf("Sorry.","Okay.","I'm tired.").distinct()),
        Challenge("Sí.","Yes.","Supervivencia",1,listOf("Sí.","No.","¿Cómo estás?").distinct(),listOf("Yes.","See you later.","I'm hungry.").distinct()),
        Challenge("No.","No.","Supervivencia",1,listOf("No.","Vale.","Estoy bien.").distinct(),listOf("No.","Good morning.","I'm thirsty.").distinct()),
        Challenge("Vale.","Okay.","Supervivencia",1,listOf("Vale.","Hasta luego.","Estoy cansado.").distinct(),listOf("Okay.","Good afternoon.","I'm sleepy.").distinct()),
        Challenge("Hasta luego.","See you later.","Supervivencia",1,listOf("Hasta luego.","Buenos días.","Estoy cansada.").distinct(),listOf("See you later.","Good night.","I don't understand.").distinct()),
        Challenge("Buenos días.","Good morning.","Supervivencia",1,listOf("Buenos días.","Buenas tardes.","Tengo hambre.").distinct(),listOf("Good morning.","How are you?","I understand.").distinct()),
        Challenge("Buenas tardes.","Good afternoon.","Supervivencia",1,listOf("Buenas tardes.","Buenas noches.","Tengo sed.").distinct(),listOf("Good afternoon.","I'm fine.","Can you repeat?").distinct()),
        Challenge("Buenas noches.","Good night.","Supervivencia",1,listOf("Buenas noches.","¿Cómo estás?","Tengo sueño.").distinct(),listOf("Good night.","I'm tired.","More slowly, please.").distinct()),
        Challenge("¿Cómo estás?","How are you?","Supervivencia",1,listOf("¿Cómo estás?","Estoy bien.","No entiendo.").distinct(),listOf("How are you?","I'm tired.","What does it mean?").distinct()),
        Challenge("Estoy bien.","I'm fine.","Supervivencia",1,listOf("Estoy bien.","Estoy cansado.","Entiendo.").distinct(),listOf("I'm fine.","I'm hungry.","How do you say it?").distinct()),
        Challenge("Estoy cansado.","I'm tired.","Supervivencia",1,listOf("Estoy cansado.","Estoy cansada.","¿Puedes repetir?").distinct(),listOf("I'm tired.","I'm thirsty.","I don't know.").distinct()),
        Challenge("Estoy cansada.","I'm tired.","Supervivencia",1,listOf("Estoy cansada.","Tengo hambre.","Más despacio, por favor.").distinct(),listOf("I'm tired.","I'm sleepy.","I need help.").distinct()),
        Challenge("Tengo hambre.","I'm hungry.","Supervivencia",1,listOf("Tengo hambre.","Tengo sed.","¿Qué significa?").distinct(),listOf("I'm hungry.","I don't understand.","Do you speak English?").distinct()),
        Challenge("Tengo sed.","I'm thirsty.","Supervivencia",1,listOf("Tengo sed.","Tengo sueño.","¿Cómo se dice?").distinct(),listOf("I'm thirsty.","I understand.","I'm learning English.").distinct()),
        Challenge("Tengo sueño.","I'm sleepy.","Supervivencia",1,listOf("Tengo sueño.","No entiendo.","No lo sé.").distinct(),listOf("I'm sleepy.","Can you repeat?","Where do you live?").distinct()),
        Challenge("No entiendo.","I don't understand.","Supervivencia",1,listOf("No entiendo.","Entiendo.","Necesito ayuda.").distinct(),listOf("I don't understand.","More slowly, please.","I live in Spain.").distinct()),
        Challenge("Entiendo.","I understand.","Supervivencia",1,listOf("Entiendo.","¿Puedes repetir?","¿Hablas inglés?").distinct(),listOf("I understand.","What does it mean?","Where are you from?").distinct()),
        Challenge("¿Puedes repetir?","Can you repeat?","Supervivencia",1,listOf("¿Puedes repetir?","Más despacio, por favor.","Estoy aprendiendo inglés.").distinct(),listOf("Can you repeat?","How do you say it?","I'm from Spain.").distinct()),
        Challenge("Más despacio, por favor.","More slowly, please.","Supervivencia",1,listOf("Más despacio, por favor.","¿Qué significa?","¿Dónde vives?").distinct(),listOf("More slowly, please.","I don't know.","What are you doing?").distinct()),
        Challenge("¿Qué significa?","What does it mean?","Supervivencia",1,listOf("¿Qué significa?","¿Cómo se dice?","Vivo en España.").distinct(),listOf("What does it mean?","I need help.","I'm working.").distinct()),
        Challenge("¿Cómo se dice?","How do you say it?","Supervivencia",1,listOf("¿Cómo se dice?","No lo sé.","¿De dónde eres?").distinct(),listOf("How do you say it?","Do you speak English?","I'm studying.").distinct()),
        Challenge("No lo sé.","I don't know.","Supervivencia",1,listOf("No lo sé.","Necesito ayuda.","Soy de España.").distinct(),listOf("I don't know.","I'm learning English.","I'm at home.").distinct()),
        Challenge("Necesito ayuda.","I need help.","Supervivencia",1,listOf("Necesito ayuda.","¿Hablas inglés?","¿Qué haces?").distinct(),listOf("I need help.","Where do you live?","I'm outside.").distinct()),
        Challenge("¿Hablas inglés?","Do you speak English?","Supervivencia",1,listOf("¿Hablas inglés?","Estoy aprendiendo inglés.","Estoy trabajando.").distinct(),listOf("Do you speak English?","I live in Spain.","I'm busy right now.").distinct()),
        Challenge("Estoy aprendiendo inglés.","I'm learning English.","Supervivencia",1,listOf("Estoy aprendiendo inglés.","¿Dónde vives?","Estoy estudiando.").distinct(),listOf("I'm learning English.","Where are you from?","I'm free right now.").distinct()),
        Challenge("¿Dónde vives?","Where do you live?","Vida cotidiana",1,listOf("¿Dónde vives?","Vivo en España.","Estoy en casa.").distinct(),listOf("Where do you live?","I'm from Spain.","I have time.").distinct()),
        Challenge("Vivo en España.","I live in Spain.","Vida cotidiana",1,listOf("Vivo en España.","¿De dónde eres?","Estoy fuera.").distinct(),listOf("I live in Spain.","What are you doing?","I don't have time.").distinct()),
        Challenge("¿De dónde eres?","Where are you from?","Vida cotidiana",1,listOf("¿De dónde eres?","Soy de España.","Ahora estoy ocupado.").distinct(),listOf("Where are you from?","I'm working.","I'm cold.").distinct()),
        Challenge("Soy de España.","I'm from Spain.","Vida cotidiana",1,listOf("Soy de España.","¿Qué haces?","Ahora estoy libre.").distinct(),listOf("I'm from Spain.","I'm studying.","I'm hot.").distinct()),
        Challenge("¿Qué haces?","What are you doing?","Vida cotidiana",1,listOf("¿Qué haces?","Estoy trabajando.","Tengo tiempo.").distinct(),listOf("What are you doing?","I'm at home.","It's cold.").distinct()),
        Challenge("Estoy trabajando.","I'm working.","Vida cotidiana",1,listOf("Estoy trabajando.","Estoy estudiando.","No tengo tiempo.").distinct(),listOf("I'm working.","I'm outside.","It's hot.").distinct()),
        Challenge("Estoy estudiando.","I'm studying.","Vida cotidiana",1,listOf("Estoy estudiando.","Estoy en casa.","Tengo frío.").distinct(),listOf("I'm studying.","I'm busy right now.","It's raining.").distinct()),
        Challenge("Estoy en casa.","I'm at home.","Vida cotidiana",1,listOf("Estoy en casa.","Estoy fuera.","Tengo calor.").distinct(),listOf("I'm at home.","I'm free right now.","I like this.").distinct()),
        Challenge("Estoy fuera.","I'm outside.","Vida cotidiana",1,listOf("Estoy fuera.","Ahora estoy ocupado.","Hace frío.").distinct(),listOf("I'm outside.","I have time.","I don't like it.").distinct()),
        Challenge("Ahora estoy ocupado.","I'm busy right now.","Vida cotidiana",1,listOf("Ahora estoy ocupado.","Ahora estoy libre.","Hace calor.").distinct(),listOf("I'm busy right now.","I don't have time.","I love it.").distinct()),
        Challenge("Ahora estoy libre.","I'm free right now.","Vida cotidiana",1,listOf("Ahora estoy libre.","Tengo tiempo.","Está lloviendo.").distinct(),listOf("I'm free right now.","I'm cold.","I don't mind.").distinct()),
        Challenge("Tengo tiempo.","I have time.","Vida cotidiana",2,listOf("Tengo tiempo.","No tengo tiempo.","Me gusta esto.").distinct(),listOf("I have time.","I'm hot.","I agree.").distinct()),
        Challenge("No tengo tiempo.","I don't have time.","Vida cotidiana",2,listOf("No tengo tiempo.","Tengo frío.","No me gusta.").distinct(),listOf("I don't have time.","It's cold.","I don't agree.").distinct()),
        Challenge("Tengo frío.","I'm cold.","Vida cotidiana",2,listOf("Tengo frío.","Tengo calor.","Me encanta.").distinct(),listOf("I'm cold.","It's hot.","What do you want to do?").distinct()),
        Challenge("Tengo calor.","I'm hot.","Vida cotidiana",2,listOf("Tengo calor.","Hace frío.","No me importa.").distinct(),listOf("I'm hot.","It's raining.","I want to rest.").distinct()),
        Challenge("Hace frío.","It's cold.","Vida cotidiana",2,listOf("Hace frío.","Hace calor.","Estoy de acuerdo.").distinct(),listOf("It's cold.","I like this.","I want to go out.").distinct()),
        Challenge("Hace calor.","It's hot.","Vida cotidiana",2,listOf("Hace calor.","Está lloviendo.","No estoy de acuerdo.").distinct(),listOf("It's hot.","I don't like it.","I want to sleep.").distinct()),
        Challenge("Está lloviendo.","It's raining.","Vida cotidiana",2,listOf("Está lloviendo.","Me gusta esto.","¿Qué quieres hacer?").distinct(),listOf("It's raining.","I love it.","I'm going to cook.").distinct()),
        Challenge("Me gusta esto.","I like this.","Vida cotidiana",2,listOf("Me gusta esto.","No me gusta.","Quiero descansar.").distinct(),listOf("I like this.","I don't mind.","I'm going to work.").distinct()),
        Challenge("No me gusta.","I don't like it.","Vida cotidiana",2,listOf("No me gusta.","Me encanta.","Quiero salir.").distinct(),listOf("I don't like it.","I agree.","I love you.").distinct()),
        Challenge("Me encanta.","I love it.","Vida cotidiana",2,listOf("Me encanta.","No me importa.","Quiero dormir.").distinct(),listOf("I love it.","I don't agree.","I miss you.").distinct()),
        Challenge("No me importa.","I don't mind.","Vida cotidiana",2,listOf("No me importa.","Estoy de acuerdo.","Voy a cocinar.").distinct(),listOf("I don't mind.","What do you want to do?","I miss you.").distinct()),
        Challenge("Estoy de acuerdo.","I agree.","Vida cotidiana",2,listOf("Estoy de acuerdo.","No estoy de acuerdo.","Voy a trabajar.").distinct(),listOf("I agree.","I want to rest.","Do you love me?").distinct()),
        Challenge("No estoy de acuerdo.","I don't agree.","Vida cotidiana",2,listOf("No estoy de acuerdo.","¿Qué quieres hacer?","Te quiero.").distinct(),listOf("I don't agree.","I want to go out.","You're very handsome.").distinct()),
        Challenge("¿Qué quieres hacer?","What do you want to do?","Vida cotidiana",2,listOf("¿Qué quieres hacer?","Quiero descansar.","Te echo de menos.").distinct(),listOf("What do you want to do?","I want to sleep.","You're very beautiful.").distinct()),
        Challenge("Quiero descansar.","I want to rest.","Vida cotidiana",2,listOf("Quiero descansar.","Quiero salir.","Te extraño.").distinct(),listOf("I want to rest.","I'm going to cook.","You make me happy.").distinct()),
        Challenge("Quiero salir.","I want to go out.","Vida cotidiana",2,listOf("Quiero salir.","Quiero dormir.","¿Me quieres?").distinct(),listOf("I want to go out.","I'm going to work.","I'm thinking about you.").distinct()),
        Challenge("Quiero dormir.","I want to sleep.","Vida cotidiana",2,listOf("Quiero dormir.","Voy a cocinar.","Eres muy guapo.").distinct(),listOf("I want to sleep.","I love you.","I want to be with you.").distinct()),
        Challenge("Voy a cocinar.","I'm going to cook.","Vida cotidiana",2,listOf("Voy a cocinar.","Voy a trabajar.","Eres muy guapa.").distinct(),listOf("I'm going to cook.","I miss you.","Come here.").distinct()),
        Challenge("Voy a trabajar.","I'm going to work.","Vida cotidiana",2,listOf("Voy a trabajar.","Te quiero.","Me haces feliz.").distinct(),listOf("I'm going to work.","I miss you.","Give me a hug.").distinct()),
        Challenge("Te quiero.","I love you.","Pareja",2,listOf("Te quiero.","Te echo de menos.","Estoy pensando en ti.").distinct(),listOf("I love you.","Do you love me?","Give me a kiss.").distinct()),
        Challenge("Te echo de menos.","I miss you.","Pareja",2,listOf("Te echo de menos.","Te extraño.","Quiero estar contigo.").distinct(),listOf("I miss you.","You're very handsome.","Do you want to go out with me?").distinct()),
        Challenge("Te extraño.","I miss you.","Pareja",2,listOf("Te extraño.","¿Me quieres?","Ven aquí.").distinct(),listOf("I miss you.","You're very beautiful.","Do you want to have dinner with me?").distinct()),
        Challenge("¿Me quieres?","Do you love me?","Pareja",2,listOf("¿Me quieres?","Eres muy guapo.","Dame un abrazo.").distinct(),listOf("Do you love me?","You make me happy.","Let's go together.").distinct()),
        Challenge("Eres muy guapo.","You're very handsome.","Pareja",2,listOf("Eres muy guapo.","Eres muy guapa.","Dame un beso.").distinct(),listOf("You're very handsome.","I'm thinking about you.","What are we doing tonight?").distinct()),
        Challenge("Eres muy guapa.","You're very beautiful.","Pareja",2,listOf("Eres muy guapa.","Me haces feliz.","¿Quieres salir conmigo?").distinct(),listOf("You're very beautiful.","I want to be with you.","I have a surprise for you.").distinct()),
        Challenge("Me haces feliz.","You make me happy.","Pareja",2,listOf("Me haces feliz.","Estoy pensando en ti.","¿Quieres cenar conmigo?").distinct(),listOf("You make me happy.","Come here.","You're my favorite person.").distinct()),
        Challenge("Estoy pensando en ti.","I'm thinking about you.","Pareja",2,listOf("Estoy pensando en ti.","Quiero estar contigo.","Vamos juntos.").distinct(),listOf("I'm thinking about you.","Give me a hug.","You make me laugh.").distinct()),
        Challenge("Quiero estar contigo.","I want to be with you.","Pareja",2,listOf("Quiero estar contigo.","Ven aquí.","¿Qué hacemos esta noche?").distinct(),listOf("I want to be with you.","Give me a kiss.","I'm happy with you.").distinct()),
        Challenge("Ven aquí.","Come here.","Pareja",2,listOf("Ven aquí.","Dame un abrazo.","Tengo una sorpresa para ti.").distinct(),listOf("Come here.","Do you want to go out with me?","Where is the hotel?").distinct()),
        Challenge("Dame un abrazo.","Give me a hug.","Pareja",2,listOf("Dame un abrazo.","Dame un beso.","Eres mi persona favorita.").distinct(),listOf("Give me a hug.","Do you want to have dinner with me?","Where is the bathroom?").distinct()),
        Challenge("Dame un beso.","Give me a kiss.","Pareja",2,listOf("Dame un beso.","¿Quieres salir conmigo?","Me haces reír.").distinct(),listOf("Give me a kiss.","Let's go together.","Where is the station?").distinct()),
        Challenge("¿Quieres salir conmigo?","Do you want to go out with me?","Pareja",2,listOf("¿Quieres salir conmigo?","¿Quieres cenar conmigo?","Estoy feliz contigo.").distinct(),listOf("Do you want to go out with me?","What are we doing tonight?","How do I get to the city center?").distinct()),
        Challenge("¿Quieres cenar conmigo?","Do you want to have dinner with me?","Pareja",2,listOf("¿Quieres cenar conmigo?","Vamos juntos.","¿Dónde está el hotel?").distinct(),listOf("Do you want to have dinner with me?","I have a surprise for you.","I need a taxi.").distinct()),
        Challenge("Vamos juntos.","Let's go together.","Pareja",2,listOf("Vamos juntos.","¿Qué hacemos esta noche?","¿Dónde está el baño?").distinct(),listOf("Let's go together.","You're my favorite person.","How much is a taxi?").distinct()),
        Challenge("¿Qué hacemos esta noche?","What are we doing tonight?","Pareja",2,listOf("¿Qué hacemos esta noche?","Tengo una sorpresa para ti.","¿Dónde está la estación?").distinct(),listOf("What are we doing tonight?","You make me laugh.","I have a reservation.").distinct()),
        Challenge("Tengo una sorpresa para ti.","I have a surprise for you.","Pareja",2,listOf("Tengo una sorpresa para ti.","Eres mi persona favorita.","¿Cómo llego al centro?").distinct(),listOf("I have a surprise for you.","I'm happy with you.","I want to make a reservation.").distinct()),
        Challenge("Eres mi persona favorita.","You're my favorite person.","Pareja",2,listOf("Eres mi persona favorita.","Me haces reír.","Necesito un taxi.").distinct(),listOf("You're my favorite person.","Where is the hotel?","What time does the train leave?").distinct()),
        Challenge("Me haces reír.","You make me laugh.","Pareja",2,listOf("Me haces reír.","Estoy feliz contigo.","¿Cuánto cuesta un taxi?").distinct(),listOf("You make me laugh.","Where is the bathroom?","What time does the bus arrive?").distinct()),
        Challenge("Estoy feliz contigo.","I'm happy with you.","Pareja",2,listOf("Estoy feliz contigo.","¿Dónde está el hotel?","Tengo una reserva.").distinct(),listOf("I'm happy with you.","Where is the station?","Where can I buy a ticket?").distinct()),
        Challenge("¿Dónde está el hotel?","Where is the hotel?","Viajes",2,listOf("¿Dónde está el hotel?","¿Dónde está el baño?","Quiero hacer una reserva.").distinct(),listOf("Where is the hotel?","How do I get to the city center?","A one-way ticket, please.").distinct()),
        Challenge("¿Dónde está el baño?","Where is the bathroom?","Viajes",2,listOf("¿Dónde está el baño?","¿Dónde está la estación?","¿A qué hora sale el tren?").distinct(),listOf("Where is the bathroom?","I need a taxi.","A return ticket, please.").distinct()),
        Challenge("¿Dónde está la estación?","Where is the station?","Viajes",3,listOf("¿Dónde está la estación?","¿Cómo llego al centro?","¿A qué hora llega el autobús?").distinct(),listOf("Where is the station?","How much is a taxi?","Is it far?").distinct()),
        Challenge("¿Cómo llego al centro?","How do I get to the city center?","Viajes",3,listOf("¿Cómo llego al centro?","Necesito un taxi.","¿Dónde puedo comprar un billete?").distinct(),listOf("How do I get to the city center?","I have a reservation.","Is it near?").distinct()),
        Challenge("Necesito un taxi.","I need a taxi.","Viajes",3,listOf("Necesito un taxi.","¿Cuánto cuesta un taxi?","Un billete de ida, por favor.").distinct(),listOf("I need a taxi.","I want to make a reservation.","Turn left.").distinct()),
        Challenge("¿Cuánto cuesta un taxi?","How much is a taxi?","Viajes",3,listOf("¿Cuánto cuesta un taxi?","Tengo una reserva.","Un billete de ida y vuelta, por favor.").distinct(),listOf("How much is a taxi?","What time does the train leave?","Turn right.").distinct()),
        Challenge("Tengo una reserva.","I have a reservation.","Viajes",3,listOf("Tengo una reserva.","Quiero hacer una reserva.","¿Está lejos?").distinct(),listOf("I have a reservation.","What time does the bus arrive?","Go straight.").distinct()),
        Challenge("Quiero hacer una reserva.","I want to make a reservation.","Viajes",3,listOf("Quiero hacer una reserva.","¿A qué hora sale el tren?","¿Está cerca?").distinct(),listOf("I want to make a reservation.","Where can I buy a ticket?","I'm lost.").distinct()),
        Challenge("¿A qué hora sale el tren?","What time does the train leave?","Viajes",3,listOf("¿A qué hora sale el tren?","¿A qué hora llega el autobús?","Gira a la izquierda.").distinct(),listOf("What time does the train leave?","A one-way ticket, please.","Can you show me on the map?").distinct()),
        Challenge("¿A qué hora llega el autobús?","What time does the bus arrive?","Viajes",3,listOf("¿A qué hora llega el autobús?","¿Dónde puedo comprar un billete?","Gira a la derecha.").distinct(),listOf("What time does the bus arrive?","A return ticket, please.","Where can we park?").distinct()),
        Challenge("¿Dónde puedo comprar un billete?","Where can I buy a ticket?","Viajes",3,listOf("¿Dónde puedo comprar un billete?","Un billete de ida, por favor.","Sigue recto.").distinct(),listOf("Where can I buy a ticket?","Is it far?","How long does it take?").distinct()),
        Challenge("Un billete de ida, por favor.","A one-way ticket, please.","Viajes",3,listOf("Un billete de ida, por favor.","Un billete de ida y vuelta, por favor.","Estoy perdido.").distinct(),listOf("A one-way ticket, please.","Is it near?","We need to leave early.").distinct()),
        Challenge("Un billete de ida y vuelta, por favor.","A return ticket, please.","Viajes",3,listOf("Un billete de ida y vuelta, por favor.","¿Está lejos?","¿Puedes mostrarme en el mapa?").distinct(),listOf("A return ticket, please.","Turn left.","What can we visit?").distinct()),
        Challenge("¿Está lejos?","Is it far?","Viajes",3,listOf("¿Está lejos?","¿Está cerca?","¿Dónde podemos aparcar?").distinct(),listOf("Is it far?","Turn right.","I want to take photos.").distinct()),
        Challenge("¿Está cerca?","Is it near?","Viajes",3,listOf("¿Está cerca?","Gira a la izquierda.","¿Cuánto tiempo tardamos?").distinct(),listOf("Is it near?","Go straight.","A table for two, please.").distinct()),
        Challenge("Gira a la izquierda.","Turn left.","Viajes",3,listOf("Gira a la izquierda.","Gira a la derecha.","Necesitamos salir temprano.").distinct(),listOf("Turn left.","I'm lost.","Can we sit here?").distinct()),
        Challenge("Gira a la derecha.","Turn right.","Viajes",3,listOf("Gira a la derecha.","Sigue recto.","¿Qué podemos visitar?").distinct(),listOf("Turn right.","Can you show me on the map?","Can we see the menu?").distinct()),
        Challenge("Sigue recto.","Go straight.","Viajes",3,listOf("Sigue recto.","Estoy perdido.","Quiero hacer fotos.").distinct(),listOf("Go straight.","Where can we park?","I want water, please.").distinct()),
        Challenge("Estoy perdido.","I'm lost.","Viajes",3,listOf("Estoy perdido.","¿Puedes mostrarme en el mapa?","Una mesa para dos, por favor.").distinct(),listOf("I'm lost.","How long does it take?","A coffee, please.").distinct()),
        Challenge("¿Puedes mostrarme en el mapa?","Can you show me on the map?","Viajes",3,listOf("¿Puedes mostrarme en el mapa?","¿Dónde podemos aparcar?","¿Podemos sentarnos aquí?").distinct(),listOf("Can you show me on the map?","We need to leave early.","Two beers, please.").distinct()),
        Challenge("¿Dónde podemos aparcar?","Where can we park?","Viajes",3,listOf("¿Dónde podemos aparcar?","¿Cuánto tiempo tardamos?","¿Podemos ver el menú?").distinct(),listOf("Where can we park?","What can we visit?","What do you recommend?").distinct()),
        Challenge("¿Cuánto tiempo tardamos?","How long does it take?","Viajes",3,listOf("¿Cuánto tiempo tardamos?","Necesitamos salir temprano.","Quiero agua, por favor.").distinct(),listOf("How long does it take?","I want to take photos.","What is the dish of the day?").distinct()),
        Challenge("Necesitamos salir temprano.","We need to leave early.","Viajes",3,listOf("Necesitamos salir temprano.","¿Qué podemos visitar?","Un café, por favor.").distinct(),listOf("We need to leave early.","A table for two, please.","I'm vegetarian.").distinct()),
        Challenge("¿Qué podemos visitar?","What can we visit?","Viajes",3,listOf("¿Qué podemos visitar?","Quiero hacer fotos.","Dos cervezas, por favor.").distinct(),listOf("What can we visit?","Can we sit here?","I'm vegetarian.").distinct()),
        Challenge("Quiero hacer fotos.","I want to take photos.","Viajes",3,listOf("Quiero hacer fotos.","Una mesa para dos, por favor.","¿Qué recomiendas?").distinct(),listOf("I want to take photos.","Can we see the menu?","No onion, please.").distinct()),
        Challenge("Una mesa para dos, por favor.","A table for two, please.","Restaurante",3,listOf("Una mesa para dos, por favor.","¿Podemos sentarnos aquí?","¿Cuál es el plato del día?").distinct(),listOf("A table for two, please.","I want water, please.","No spicy food, please.").distinct()),
        Challenge("¿Podemos sentarnos aquí?","Can we sit here?","Restaurante",3,listOf("¿Podemos sentarnos aquí?","¿Podemos ver el menú?","Soy vegetariano.").distinct(),listOf("Can we sit here?","A coffee, please.","Does it have meat?").distinct()),
        Challenge("¿Podemos ver el menú?","Can we see the menu?","Restaurante",3,listOf("¿Podemos ver el menú?","Quiero agua, por favor.","Soy vegetariana.").distinct(),listOf("Can we see the menu?","Two beers, please.","Does it have fish?").distinct()),
        Challenge("Quiero agua, por favor.","I want water, please.","Restaurante",3,listOf("Quiero agua, por favor.","Un café, por favor.","Sin cebolla, por favor.").distinct(),listOf("I want water, please.","What do you recommend?","It's delicious.").distinct()),
        Challenge("Un café, por favor.","A coffee, please.","Restaurante",3,listOf("Un café, por favor.","Dos cervezas, por favor.","Sin picante, por favor.").distinct(),listOf("A coffee, please.","What is the dish of the day?","It's very good.").distinct()),
        Challenge("Dos cervezas, por favor.","Two beers, please.","Restaurante",3,listOf("Dos cervezas, por favor.","¿Qué recomiendas?","¿Tiene carne?").distinct(),listOf("Two beers, please.","I'm vegetarian.","The bill, please.").distinct()),
        Challenge("¿Qué recomiendas?","What do you recommend?","Restaurante",3,listOf("¿Qué recomiendas?","¿Cuál es el plato del día?","¿Tiene pescado?").distinct(),listOf("What do you recommend?","I'm vegetarian.","Can we pay by card?").distinct()),
        Challenge("¿Cuál es el plato del día?","What is the dish of the day?","Restaurante",3,listOf("¿Cuál es el plato del día?","Soy vegetariano.","Está delicioso.").distinct(),listOf("What is the dish of the day?","No onion, please.","Is service included?").distinct()),
        Challenge("Soy vegetariano.","I'm vegetarian.","Restaurante",3,listOf("Soy vegetariano.","Soy vegetariana.","Está muy bueno.").distinct(),listOf("I'm vegetarian.","No spicy food, please.","To take away, please.").distinct()),
        Challenge("Soy vegetariana.","I'm vegetarian.","Restaurante",3,listOf("Soy vegetariana.","Sin cebolla, por favor.","La cuenta, por favor.").distinct(),listOf("I'm vegetarian.","Does it have meat?","How much is this?").distinct()),
        Challenge("Sin cebolla, por favor.","No onion, please.","Restaurante",3,listOf("Sin cebolla, por favor.","Sin picante, por favor.","¿Podemos pagar con tarjeta?").distinct(),listOf("No onion, please.","Does it have fish?","It's too expensive.").distinct()),
        Challenge("Sin picante, por favor.","No spicy food, please.","Restaurante",3,listOf("Sin picante, por favor.","¿Tiene carne?","¿Está incluido el servicio?").distinct(),listOf("No spicy food, please.","It's delicious.","Do you have something cheaper?").distinct()),
        Challenge("¿Tiene carne?","Does it have meat?","Restaurante",3,listOf("¿Tiene carne?","¿Tiene pescado?","Para llevar, por favor.").distinct(),listOf("Does it have meat?","It's very good.","I like this one.").distinct()),
        Challenge("¿Tiene pescado?","Does it have fish?","Restaurante",3,listOf("¿Tiene pescado?","Está delicioso.","¿Cuánto cuesta esto?").distinct(),listOf("Does it have fish?","The bill, please.","I like this one.").distinct()),
        Challenge("Está delicioso.","It's delicious.","Restaurante",3,listOf("Está delicioso.","Está muy bueno.","Es demasiado caro.").distinct(),listOf("It's delicious.","Can we pay by card?","Can I try it on?").distinct()),
        Challenge("Está muy bueno.","It's very good.","Restaurante",3,listOf("Está muy bueno.","La cuenta, por favor.","¿Tienes algo más barato?").distinct(),listOf("It's very good.","Is service included?","Do you have another size?").distinct()),
        Challenge("La cuenta, por favor.","The bill, please.","Restaurante",3,listOf("La cuenta, por favor.","¿Podemos pagar con tarjeta?","Me gusta este.").distinct(),listOf("The bill, please.","To take away, please.","Do you have another color?").distinct()),
        Challenge("¿Podemos pagar con tarjeta?","Can we pay by card?","Restaurante",3,listOf("¿Podemos pagar con tarjeta?","¿Está incluido el servicio?","Me gusta esta.").distinct(),listOf("Can we pay by card?","How much is this?","I'm just looking.").distinct()),
        Challenge("¿Está incluido el servicio?","Is service included?","Restaurante",4,listOf("¿Está incluido el servicio?","Para llevar, por favor.","¿Puedo probarlo?").distinct(),listOf("Is service included?","It's too expensive.","I'll take it.").distinct()),
        Challenge("Para llevar, por favor.","To take away, please.","Restaurante",4,listOf("Para llevar, por favor.","¿Cuánto cuesta esto?","¿Tienes otra talla?").distinct(),listOf("To take away, please.","Do you have something cheaper?","Can I pay by card?").distinct()),
        Challenge("¿Cuánto cuesta esto?","How much is this?","Compras",4,listOf("¿Cuánto cuesta esto?","Es demasiado caro.","¿Tienes otro color?").distinct(),listOf("How much is this?","I like this one.","Do you accept cash?").distinct()),
        Challenge("Es demasiado caro.","It's too expensive.","Compras",4,listOf("Es demasiado caro.","¿Tienes algo más barato?","Solo estoy mirando.").distinct(),listOf("It's too expensive.","I like this one.","I need a bag.").distinct()),
        Challenge("¿Tienes algo más barato?","Do you have something cheaper?","Compras",4,listOf("¿Tienes algo más barato?","Me gusta este.","Me lo llevo.").distinct(),listOf("Do you have something cheaper?","Can I try it on?","Where are the fitting rooms?").distinct()),
        Challenge("Me gusta este.","I like this one.","Compras",4,listOf("Me gusta este.","Me gusta esta.","¿Puedo pagar con tarjeta?").distinct(),listOf("I like this one.","Do you have another size?","Can I return it?").distinct()),
        Challenge("Me gusta esta.","I like this one.","Compras",4,listOf("Me gusta esta.","¿Puedo probarlo?","¿Aceptáis efectivo?").distinct(),listOf("I like this one.","Do you have another color?","I need to buy food.").distinct()),
        Challenge("¿Puedo probarlo?","Can I try it on?","Compras",4,listOf("¿Puedo probarlo?","¿Tienes otra talla?","Necesito una bolsa.").distinct(),listOf("Can I try it on?","I'm just looking.","Where is the supermarket?").distinct()),
        Challenge("¿Tienes otra talla?","Do you have another size?","Compras",4,listOf("¿Tienes otra talla?","¿Tienes otro color?","¿Dónde están los probadores?").distinct(),listOf("Do you have another size?","I'll take it.","I want to buy a gift.").distinct()),
        Challenge("¿Tienes otro color?","Do you have another color?","Compras",4,listOf("¿Tienes otro color?","Solo estoy mirando.","¿Puedo devolverlo?").distinct(),listOf("Do you have another color?","Can I pay by card?","Is there a discount?").distinct()),
        Challenge("Solo estoy mirando.","I'm just looking.","Compras",4,listOf("Solo estoy mirando.","Me lo llevo.","Necesito comprar comida.").distinct(),listOf("I'm just looking.","Do you accept cash?","How much is it in total?").distinct()),
        Challenge("Me lo llevo.","I'll take it.","Compras",4,listOf("Me lo llevo.","¿Puedo pagar con tarjeta?","¿Dónde está el supermercado?").distinct(),listOf("I'll take it.","I need a bag.","What's your name?").distinct()),
        Challenge("¿Puedo pagar con tarjeta?","Can I pay by card?","Compras",4,listOf("¿Puedo pagar con tarjeta?","¿Aceptáis efectivo?","Quiero comprar un regalo.").distinct(),listOf("Can I pay by card?","Where are the fitting rooms?","My name is Toni.").distinct()),
        Challenge("¿Aceptáis efectivo?","Do you accept cash?","Compras",4,listOf("¿Aceptáis efectivo?","Necesito una bolsa.","¿Hay descuento?").distinct(),listOf("Do you accept cash?","Can I return it?","How old are you?").distinct()),
        Challenge("Necesito una bolsa.","I need a bag.","Compras",4,listOf("Necesito una bolsa.","¿Dónde están los probadores?","¿Cuánto cuesta en total?").distinct(),listOf("I need a bag.","I need to buy food.","I'm thirty years old.").distinct()),
        Challenge("¿Dónde están los probadores?","Where are the fitting rooms?","Compras",4,listOf("¿Dónde están los probadores?","¿Puedo devolverlo?","¿Cómo te llamas?").distinct(),listOf("Where are the fitting rooms?","Where is the supermarket?","What do you like to do?").distinct()),
        Challenge("¿Puedo devolverlo?","Can I return it?","Compras",4,listOf("¿Puedo devolverlo?","Necesito comprar comida.","Me llamo Toni.").distinct(),listOf("Can I return it?","I want to buy a gift.","I like travelling.").distinct()),
        Challenge("Necesito comprar comida.","I need to buy food.","Compras",4,listOf("Necesito comprar comida.","¿Dónde está el supermercado?","¿Qué edad tienes?").distinct(),listOf("I need to buy food.","Is there a discount?","I like listening to music.").distinct()),
        Challenge("¿Dónde está el supermercado?","Where is the supermarket?","Compras",4,listOf("¿Dónde está el supermercado?","Quiero comprar un regalo.","Tengo treinta años.").distinct(),listOf("Where is the supermarket?","How much is it in total?","I like watching movies.").distinct()),
        Challenge("Quiero comprar un regalo.","I want to buy a gift.","Compras",4,listOf("Quiero comprar un regalo.","¿Hay descuento?","¿Qué te gusta hacer?").distinct(),listOf("I want to buy a gift.","What's your name?","What's your favorite food?").distinct()),
        Challenge("¿Hay descuento?","Is there a discount?","Compras",4,listOf("¿Hay descuento?","¿Cuánto cuesta en total?","Me gusta viajar.").distinct(),listOf("Is there a discount?","My name is Toni.","My favorite food is pizza.").distinct()),
        Challenge("¿Cuánto cuesta en total?","How much is it in total?","Compras",4,listOf("¿Cuánto cuesta en total?","¿Cómo te llamas?","Me gusta escuchar música.").distinct(),listOf("How much is it in total?","How old are you?","What music do you like?").distinct()),
        Challenge("¿Cómo te llamas?","What's your name?","Conversación",4,listOf("¿Cómo te llamas?","Me llamo Toni.","Me gusta ver películas.").distinct(),listOf("What's your name?","I'm thirty years old.","What movie do you want to watch?").distinct()),
        Challenge("Me llamo Toni.","My name is Toni.","Conversación",4,listOf("Me llamo Toni.","¿Qué edad tienes?","¿Cuál es tu comida favorita?").distinct(),listOf("My name is Toni.","What do you like to do?","What plans do you have?").distinct()),
        Challenge("¿Qué edad tienes?","How old are you?","Conversación",4,listOf("¿Qué edad tienes?","Tengo treinta años.","Mi comida favorita es la pizza.").distinct(),listOf("How old are you?","I like travelling.","What did you do yesterday?").distinct()),
        Challenge("Tengo treinta años.","I'm thirty years old.","Conversación",4,listOf("Tengo treinta años.","¿Qué te gusta hacer?","¿Qué música te gusta?").distinct(),listOf("I'm thirty years old.","I like listening to music.","I worked yesterday.").distinct()),
        Challenge("¿Qué te gusta hacer?","What do you like to do?","Conversación",4,listOf("¿Qué te gusta hacer?","Me gusta viajar.","¿Qué película quieres ver?").distinct(),listOf("What do you like to do?","I like watching movies.","Tomorrow I'm going to rest.").distinct()),
        Challenge("Me gusta viajar.","I like travelling.","Conversación",4,listOf("Me gusta viajar.","Me gusta escuchar música.","¿Qué planes tienes?").distinct(),listOf("I like travelling.","What's your favorite food?","Do you want to come with me?").distinct()),
        Challenge("Me gusta escuchar música.","I like listening to music.","Conversación",4,listOf("Me gusta escuchar música.","Me gusta ver películas.","¿Qué hiciste ayer?").distinct(),listOf("I like listening to music.","My favorite food is pizza.","Of course.").distinct()),
        Challenge("Me gusta ver películas.","I like watching movies.","Conversación",4,listOf("Me gusta ver películas.","¿Cuál es tu comida favorita?","Ayer trabajé.").distinct(),listOf("I like watching movies.","What music do you like?","Maybe tomorrow.").distinct()),
        Challenge("¿Cuál es tu comida favorita?","What's your favorite food?","Conversación",4,listOf("¿Cuál es tu comida favorita?","Mi comida favorita es la pizza.","Mañana voy a descansar.").distinct(),listOf("What's your favorite food?","What movie do you want to watch?","I can't today.").distinct()),
        Challenge("Mi comida favorita es la pizza.","My favorite food is pizza.","Conversación",4,listOf("Mi comida favorita es la pizza.","¿Qué música te gusta?","¿Quieres venir conmigo?").distinct(),listOf("My favorite food is pizza.","What plans do you have?","What time is it?").distinct()),
        Challenge("¿Qué música te gusta?","What music do you like?","Conversación",4,listOf("¿Qué música te gusta?","¿Qué película quieres ver?","Claro que sí.").distinct(),listOf("What music do you like?","What did you do yesterday?","It's eight o'clock.").distinct()),
        Challenge("¿Qué película quieres ver?","What movie do you want to watch?","Conversación",4,listOf("¿Qué película quieres ver?","¿Qué planes tienes?","Quizá mañana.").distinct(),listOf("What movie do you want to watch?","I worked yesterday.","What day is it today?").distinct()),
        Challenge("¿Qué planes tienes?","What plans do you have?","Conversación",4,listOf("¿Qué planes tienes?","¿Qué hiciste ayer?","No puedo hoy.").distinct(),listOf("What plans do you have?","Tomorrow I'm going to rest.","Today is Monday.").distinct()),
        Challenge("¿Qué hiciste ayer?","What did you do yesterday?","Conversación",4,listOf("¿Qué hiciste ayer?","Ayer trabajé.","¿Qué hora es?").distinct(),listOf("What did you do yesterday?","Do you want to come with me?","See you tomorrow.").distinct()),
        Challenge("Ayer trabajé.","I worked yesterday.","Conversación",4,listOf("Ayer trabajé.","Mañana voy a descansar.","Son las ocho.").distinct(),listOf("I worked yesterday.","Of course.","I have a meeting.").distinct()),
        Challenge("Mañana voy a descansar.","Tomorrow I'm going to rest.","Conversación",4,listOf("Mañana voy a descansar.","¿Quieres venir conmigo?","¿Qué día es hoy?").distinct(),listOf("Tomorrow I'm going to rest.","Maybe tomorrow.","I'm working now.").distinct()),
        Challenge("¿Quieres venir conmigo?","Do you want to come with me?","Conversación",4,listOf("¿Quieres venir conmigo?","Claro que sí.","Hoy es lunes.").distinct(),listOf("Do you want to come with me?","I can't today.","I'll call you later.").distinct()),
        Challenge("Claro que sí.","Of course.","Conversación",4,listOf("Claro que sí.","Quizá mañana.","Nos vemos mañana.").distinct(),listOf("Of course.","What time is it?","Send me a message.").distinct()),
        Challenge("Quizá mañana.","Maybe tomorrow.","Conversación",4,listOf("Quizá mañana.","No puedo hoy.","Tengo una reunión.").distinct(),listOf("Maybe tomorrow.","It's eight o'clock.","Can you help me?").distinct()),
        Challenge("No puedo hoy.","I can't today.","Conversación",5,listOf("No puedo hoy.","¿Qué hora es?","Estoy trabajando ahora.").distinct(),listOf("I can't today.","What day is it today?","I need five minutes.").distinct()),
        Challenge("¿Qué hora es?","What time is it?","Conversación",5,listOf("¿Qué hora es?","Son las ocho.","Te llamo después.").distinct(),listOf("What time is it?","Today is Monday.","I'm almost ready.").distinct()),
        Challenge("Son las ocho.","It's eight o'clock.","Conversación",5,listOf("Son las ocho.","¿Qué día es hoy?","Envíame un mensaje.").distinct(),listOf("It's eight o'clock.","See you tomorrow.","I'm almost ready.").distinct()),
        Challenge("¿Qué día es hoy?","What day is it today?","Conversación",5,listOf("¿Qué día es hoy?","Hoy es lunes.","¿Puedes ayudarme?").distinct(),listOf("What day is it today?","I have a meeting.","I'm finished.").distinct()),
        Challenge("Hoy es lunes.","Today is Monday.","Conversación",5,listOf("Hoy es lunes.","Nos vemos mañana.","Necesito cinco minutos.").distinct(),listOf("Today is Monday.","I'm working now.","We start at nine.").distinct()),
        Challenge("Nos vemos mañana.","See you tomorrow.","Conversación",5,listOf("Nos vemos mañana.","Tengo una reunión.","Estoy casi listo.").distinct(),listOf("See you tomorrow.","I'll call you later.","I finish at five.").distinct()),
        Challenge("Tengo una reunión.","I have a meeting.","Trabajo",5,listOf("Tengo una reunión.","Estoy trabajando ahora.","Estoy casi lista.").distinct(),listOf("I have a meeting.","Send me a message.","Can you wait?").distinct()),
        Challenge("Estoy trabajando ahora.","I'm working now.","Trabajo",5,listOf("Estoy trabajando ahora.","Te llamo después.","Ya terminé.").distinct(),listOf("I'm working now.","Can you help me?","I need a break.").distinct()),
        Challenge("Te llamo después.","I'll call you later.","Trabajo",5,listOf("Te llamo después.","Envíame un mensaje.","Empezamos a las nueve.").distinct(),listOf("I'll call you later.","I need five minutes.","I have a lot of work.").distinct()),
        Challenge("Envíame un mensaje.","Send me a message.","Trabajo",5,listOf("Envíame un mensaje.","¿Puedes ayudarme?","Termino a las cinco.").distinct(),listOf("Send me a message.","I'm almost ready.","I'm relaxed today.").distinct()),
        Challenge("¿Puedes ayudarme?","Can you help me?","Trabajo",5,listOf("¿Puedes ayudarme?","Necesito cinco minutos.","¿Puedes esperar?").distinct(),listOf("Can you help me?","I'm almost ready.","I have a headache.").distinct()),
        Challenge("Necesito cinco minutos.","I need five minutes.","Trabajo",5,listOf("Necesito cinco minutos.","Estoy casi listo.","Necesito un descanso.").distinct(),listOf("I need five minutes.","I'm finished.","My stomach hurts.").distinct()),
        Challenge("Estoy casi listo.","I'm almost ready.","Trabajo",5,listOf("Estoy casi listo.","Estoy casi lista.","Tengo mucho trabajo.").distinct(),listOf("I'm almost ready.","We start at nine.","I need a doctor.").distinct()),
        Challenge("Estoy casi lista.","I'm almost ready.","Trabajo",5,listOf("Estoy casi lista.","Ya terminé.","Hoy estoy tranquilo.").distinct(),listOf("I'm almost ready.","I finish at five.","I need a pharmacy.").distinct()),
        Challenge("Ya terminé.","I'm finished.","Trabajo",5,listOf("Ya terminé.","Empezamos a las nueve.","Me duele la cabeza.").distinct(),listOf("I'm finished.","Can you wait?","Where is the hospital?").distinct()),
        Challenge("Empezamos a las nueve.","We start at nine.","Trabajo",5,listOf("Empezamos a las nueve.","Termino a las cinco.","Me duele el estómago.").distinct(),listOf("We start at nine.","I need a break.","I don't feel well.").distinct()),
        Challenge("Termino a las cinco.","I finish at five.","Trabajo",5,listOf("Termino a las cinco.","¿Puedes esperar?","Necesito un médico.").distinct(),listOf("I finish at five.","I have a lot of work.","I'm better.").distinct()),
        Challenge("¿Puedes esperar?","Can you wait?","Trabajo",5,listOf("¿Puedes esperar?","Necesito un descanso.","Necesito una farmacia.").distinct(),listOf("Can you wait?","I'm relaxed today.","I need to rest.").distinct()),
        Challenge("Necesito un descanso.","I need a break.","Trabajo",5,listOf("Necesito un descanso.","Tengo mucho trabajo.","¿Dónde está el hospital?").distinct(),listOf("I need a break.","I have a headache.","Do you have water?").distinct()),
        Challenge("Tengo mucho trabajo.","I have a lot of work.","Trabajo",5,listOf("Tengo mucho trabajo.","Hoy estoy tranquilo.","No me siento bien.").distinct(),listOf("I have a lot of work.","My stomach hurts.","I need to sleep.").distinct()),
        Challenge("Hoy estoy tranquilo.","I'm relaxed today.","Trabajo",5,listOf("Hoy estoy tranquilo.","Me duele la cabeza.","Estoy mejor.").distinct(),listOf("I'm relaxed today.","I need a doctor.","The cat speaks English.").distinct()),
        Challenge("Me duele la cabeza.","I have a headache.","Salud y necesidades",5,listOf("Me duele la cabeza.","Me duele el estómago.","Necesito descansar.").distinct(),listOf("I have a headache.","I need a pharmacy.","My dog wants pizza.").distinct()),
        Challenge("Me duele el estómago.","My stomach hurts.","Salud y necesidades",5,listOf("Me duele el estómago.","Necesito un médico.","¿Tienes agua?").distinct(),listOf("My stomach hurts.","Where is the hospital?","The penguin is at the hotel.").distinct()),
        Challenge("Necesito un médico.","I need a doctor.","Salud y necesidades",5,listOf("Necesito un médico.","Necesito una farmacia.","Necesito dormir.").distinct(),listOf("I need a doctor.","I don't feel well.","I've lost my shoes.").distinct()),
        Challenge("Necesito una farmacia.","I need a pharmacy.","Salud y necesidades",5,listOf("Necesito una farmacia.","¿Dónde está el hospital?","El gato habla inglés.").distinct(),listOf("I need a pharmacy.","I'm better.","Why is there a duck in the kitchen?").distinct()),
        Challenge("¿Dónde está el hospital?","Where is the hospital?","Salud y necesidades",5,listOf("¿Dónde está el hospital?","No me siento bien.","Mi perro quiere pizza.").distinct(),listOf("Where is the hospital?","I need to rest.","My coffee is looking at me.").distinct()),
        Challenge("No me siento bien.","I don't feel well.","Salud y necesidades",5,listOf("No me siento bien.","Estoy mejor.","El pingüino está en el hotel.").distinct(),listOf("I don't feel well.","Do you have water?","The dog is driving the car.").distinct()),
        Challenge("Estoy mejor.","I'm better.","Salud y necesidades",5,listOf("Estoy mejor.","Necesito descansar.","He perdido mis zapatos.").distinct(),listOf("I'm better.","I need to sleep.","I need a million pizzas.").distinct()),
        Challenge("Necesito descansar.","I need to rest.","Salud y necesidades",5,listOf("Necesito descansar.","¿Tienes agua?","¿Por qué hay un pato en la cocina?").distinct(),listOf("I need to rest.","The cat speaks English.","Today I'm going to marry a toaster.").distinct()),
        Challenge("¿Tienes agua?","Do you have water?","Salud y necesidades",5,listOf("¿Tienes agua?","Necesito dormir.","Mi café me está mirando.").distinct(),listOf("Do you have water?","My dog wants pizza.","My cat thinks it's the boss.").distinct()),
        Challenge("Necesito dormir.","I need to sleep.","Salud y necesidades",5,listOf("Necesito dormir.","El gato habla inglés.","El perro conduce el coche.").distinct(),listOf("I need to sleep.","The penguin is at the hotel.","Hello.").distinct()),
        Challenge("El gato habla inglés.","The cat speaks English.","Humor",5,listOf("El gato habla inglés.","Mi perro quiere pizza.","Necesito un millón de pizzas.").distinct(),listOf("The cat speaks English.","I've lost my shoes.","Goodbye.").distinct()),
        Challenge("Mi perro quiere pizza.","My dog wants pizza.","Humor",5,listOf("Mi perro quiere pizza.","El pingüino está en el hotel.","Hoy voy a casarme con una tostadora.").distinct(),listOf("My dog wants pizza.","Why is there a duck in the kitchen?","Please.").distinct()),
        Challenge("El pingüino está en el hotel.","The penguin is at the hotel.","Humor",5,listOf("El pingüino está en el hotel.","He perdido mis zapatos.","Mi gato cree que es el jefe.").distinct(),listOf("The penguin is at the hotel.","My coffee is looking at me.","Thank you.").distinct()),
        Challenge("He perdido mis zapatos.","I've lost my shoes.","Humor",5,listOf("He perdido mis zapatos.","¿Por qué hay un pato en la cocina?","Hola.").distinct(),listOf("I've lost my shoes.","The dog is driving the car.","You're welcome.").distinct()),
        Challenge("¿Por qué hay un pato en la cocina?","Why is there a duck in the kitchen?","Humor",5,listOf("¿Por qué hay un pato en la cocina?","Mi café me está mirando.","Adiós.").distinct(),listOf("Why is there a duck in the kitchen?","I need a million pizzas.","Sorry.").distinct()),
        Challenge("Mi café me está mirando.","My coffee is looking at me.","Humor",5,listOf("Mi café me está mirando.","El perro conduce el coche.","Por favor.").distinct(),listOf("My coffee is looking at me.","Today I'm going to marry a toaster.","Yes.").distinct()),
        Challenge("El perro conduce el coche.","The dog is driving the car.","Humor",5,listOf("El perro conduce el coche.","Necesito un millón de pizzas.","Gracias.").distinct(),listOf("The dog is driving the car.","My cat thinks it's the boss.","No.").distinct()),
        Challenge("Necesito un millón de pizzas.","I need a million pizzas.","Humor",5,listOf("Necesito un millón de pizzas.","Hoy voy a casarme con una tostadora.","De nada.").distinct(),listOf("I need a million pizzas.","Hello.","Okay.").distinct()),
        Challenge("Hoy voy a casarme con una tostadora.","Today I'm going to marry a toaster.","Humor",5,listOf("Hoy voy a casarme con una tostadora.","Mi gato cree que es el jefe.","Perdón.").distinct(),listOf("Today I'm going to marry a toaster.","Goodbye.","See you later.").distinct()),
        Challenge("Mi gato cree que es el jefe.","My cat thinks it's the boss.","Humor",5,listOf("Mi gato cree que es el jefe.","Hola.","Sí.").distinct(),listOf("My cat thinks it's the boss.","Please.","Good morning.").distinct()),
    )

    override fun onCreate(state: Bundle?) {
        super.onCreate(state)
        setContentView(R.layout.activity_main)
        bind()
        auth = FirebaseAuth.getInstance()
        db = FirebaseDatabase.getInstance(dbUrl).reference
        tts = TextToSpeech(this, this)

        auth.signInAnonymously()
            .addOnSuccessListener { status.text = "🟢 Conectado a Firebase. Elige quién juega." }
            .addOnFailureListener { status.text = "⚠️ No se pudo conectar: ${it.message}" }

        findViewById<Button>(R.id.toniButton).setOnClickListener { choose("TONI") }
        findViewById<Button>(R.id.ilonaButton).setOnClickListener { choose("ILONA") }
        findViewById<Button>(R.id.createButton).setOnClickListener { createRoom() }
        findViewById<Button>(R.id.joinButton).setOnClickListener { joinRoom() }
        next.setOnClickListener { renderRoom() }
        end.setOnClickListener { finishGame() }
    }

    private fun bind() {
        status=findViewById(R.id.status)
        roomInfo=findViewById(R.id.roomInfo)
        score=findViewById(R.id.score)
        mode=findViewById(R.id.category)
        question=findViewById(R.id.question)
        answers=findViewById(R.id.answers)
        feedback=findViewById(R.id.feedback)
        next=findViewById(R.id.nextButton)
        end=findViewById(R.id.endButton)
        rolePanel=findViewById(R.id.rolePanel)
        roomPanel=findViewById(R.id.roomPanel)
        code=findViewById(R.id.roomCode)
    }

    private fun choose(r:String) {
        role=r
        status.text=if(r=="TONI")
            "TONI 🇪🇸 → 🇬🇧 Inglés"
        else
            "ILONA 🇱🇻 → 🇪🇸 Español\nLatviski: tu mācies spāņu valodu."
        rolePanel.visibility=View.GONE
        roomPanel.visibility=View.VISIBLE
        code.visibility=View.VISIBLE
        findViewById<Button>(R.id.createButton).visibility=if(r=="TONI") View.VISIBLE else View.GONE
        findViewById<Button>(R.id.joinButton).visibility=if(r=="ILONA") View.VISIBLE else View.GONE
    }

    private fun newCode(): String {
        val chars="ABCDEFGHJKLMNPQRSTUVWXYZ23456789"
        return (1..6).map { chars.random() }.joinToString("")
    }

    private fun roomRef() = db.child("rooms").child(room)

    private fun createRoom() {
        if(auth.currentUser==null){ status.text="Conectando…"; return }
        room=newCode()
        val data=mapOf(
            "active" to true,
            "round" to 0,
            "turnRole" to "TONI",
            "challengeIndex" to 0,
            "toniScore" to 0,
            "ilonaScore" to 0,
            "toniStreak" to 0,
            "ilonaStreak" to 0,
            "level" to 1,
            "lastResult" to "",
            "lastPlayer" to "",
            "players" to mapOf("toni" to false, "ilona" to false)
        )
        roomRef().setValue(data).addOnSuccessListener {
            status.text="Sala creada. Conectando a Ilona…"
            roomInfo.text="SALA $room"
            setPresence("toni")
            listen()
        }.addOnFailureListener { status.text="❌ ${it.message}" }
    }

    private fun joinRoom() {
        room=code.text.toString().trim().uppercase()
        if(room.length!=6){ status.text="Escribe un código de 6 caracteres."; return }
        roomRef().get().addOnSuccessListener { snap ->
            if(!snap.exists()){
                status.text="❌ No existe esa sala."
                return@addOnSuccessListener
            }
            if(snap.child("active").getValue(Boolean::class.java)==false){
                status.text="❌ Esa partida ya terminó."
                return@addOnSuccessListener
            }
            roomInfo.text="SALA $room"
            setPresence("ilona")
            listen()
        }.addOnFailureListener { status.text="❌ ${it.message}" }
    }

    private fun setPresence(player:String) {
        val connectedRef=db.child(".info").child("connected")
        connectedRef.addValueEventListener(object:ValueEventListener{
            override fun onCancelled(e:DatabaseError) {
                status.text="⚠️ No se pudo comprobar la conexión."
            }
            override fun onDataChange(s:DataSnapshot) {
                val connected=s.getValue(Boolean::class.java) ?: false
                if(!connected) return
                val ref=roomRef().child("players").child(player)
                ref.onDisconnect().setValue(false)
                ref.setValue(true).addOnSuccessListener {
                    status.text=if(role=="TONI") "🟢 Toni conectado. Esperando a Ilona…" else "🟢 Ilona conectada. Esperando a Toni…"
                }
                connectedRef.removeEventListener(this)
            }
        })
    }

    private fun listen() {
        listener?.let { roomRef().removeEventListener(it) }
        listener=object:ValueEventListener{
            override fun onCancelled(e:DatabaseError) {
                status.text="⚠️ Conexión temporalmente perdida. Reintentando…"
            }
            override fun onDataChange(s:DataSnapshot) {
                round=s.child("round").getValue(Int::class.java)?:0
                turnRole=s.child("turnRole").getValue(String::class.java)?:"TONI"
                toniScore=s.child("toniScore").getValue(Int::class.java)?:0
                ilonaScore=s.child("ilonaScore").getValue(Int::class.java)?:0
                toniStreak=s.child("toniStreak").getValue(Int::class.java)?:0
                ilonaStreak=s.child("ilonaStreak").getValue(Int::class.java)?:0
                level=s.child("level").getValue(Int::class.java)?:1
                toniOnline=s.child("players").child("toni").getValue(Boolean::class.java)?:false
                ilonaOnline=s.child("players").child("ilona").getValue(Boolean::class.java)?:false
                val active=s.child("active").getValue(Boolean::class.java)?:true
                updateScore()
                if(active) renderRoom(s) else showFinished()
            }
        }
        roomRef().addValueEventListener(listener!!)
    }

    private fun updateScore() {
        score.text="TONI 🇬🇧 $toniScore  •  ILONA 🇪🇸 $ilonaScore\n🔥 $toniStreak / $ilonaStreak   •   Nivel $level   •   ♾️"
    }

    private fun challengeFor(index:Int):Challenge {
        return bank[index.mod(bank.size)]
    }

    private fun renderRoom(snapshot:DataSnapshot?=null) {
        answered=false
        next.visibility=View.GONE
        end.visibility=View.VISIBLE
        val conn="TONI ${if(toniOnline)"🟢 conectado" else "⚪ esperando"}   •   ILONA ${if(ilonaOnline)"🟢 conectada" else "⚪ esperando"}"
        roomInfo.text="SALA $room\n$conn"

        if(!toniOnline || !ilonaOnline){
            mode.text="Preparando partida…"
            question.text="❤️ Esperando a que los dos estén conectados"
            answers.removeAllViews()
            feedback.text="Cuando aparezcan los dos puntos verdes, comienza el turno de Toni."
            status.text=if(role=="TONI") "Esperando a Ilona…" else "Conectada. Esperando a Toni…"
            return
        }

        val idx=snapshot?.child("challengeIndex")?.getValue(Int::class.java)
            ?: (round*7).mod(bank.size)
        val c=challengeFor(idx)
        mode.text="${c.category}  •  Nivel ${c.level}"

        if(turnRole==role) {
            status.text="🎮 ¡Es tu turno!"
            if(role=="TONI") {
                question.text="🇪🇸 ${c.es}\n\n👉 Elige en inglés 🇬🇧"
                showOptions(c.enOptions, c.en, c)
            } else {
                question.text="🇬🇧 ${c.en}\n\n👉 Elige en español 🇪🇸"
                showOptions(c.esOptions, c.es, c)
            }
        } else {
            status.text="👀 Turno de ${if(turnRole=="TONI")"TONI" else "ILONA"}"
            if(turnRole=="ILONA") {
                // Toni can see Ilona's complete challenge, including Spanish (his native language).
                question.text="👀 ILONA está practicando español 🇪🇸\n\n🇬🇧 ${c.en}\n➡️ 🇪🇸 ${c.es}"
            } else {
                // Ilona can see Toni's complete challenge, including English target.
                question.text="👀 TONI está practicando inglés 🇬🇧\n\n🇪🇸 ${c.es}\n➡️ 🇬🇧 ${c.en}"
            }
            answers.removeAllViews()
            feedback.text="❤️ ${if(turnRole=="TONI")"Toni está respondiendo…" else "Ilona está respondiendo…"}"
        }
    }

    private fun showOptions(options:List<String>, answer:String, c:Challenge) {
        answers.removeAllViews()
        options.shuffled().forEach { value ->
            Button(this).apply {
                text=value
                isAllCaps=false
                setOnClickListener { answer(value, answer, c) }
                answers.addView(this)
            }
        }
        feedback.text=""
    }

    private fun answer(value:String, correctAnswer:String, c:Challenge) {
        if(answered || turnRole!=role || !toniOnline || !ilonaOnline) return
        answered=true
        val correct=value==correctAnswer
        val nextRound=round+1
        val nextRole=if(role=="TONI")"ILONA" else "TONI"

        var newToni=toniScore
        var newIlona=ilonaScore
        var newToniStreak=toniStreak
        var newIlonaStreak=ilonaStreak
        if(role=="TONI") {
            newToniStreak=if(correct) toniStreak+1 else 0
            if(correct) newToni++
        } else {
            newIlonaStreak=if(correct) ilonaStreak+1 else 0
            if(correct) newIlona++
        }

        val total=newToni+newIlona
        val newLevel=(1 + total/10).coerceAtMost(5)
        val nextIndex=(round*7 + 11 + c.level*3).mod(bank.size)

        feedback.text=if(correct)
            "🎉 ¡Correcto! +1"
        else
            "💡 Correcta: $correctAnswer"

        roomRef().updateChildren(mapOf(
            "round" to nextRound,
            "turnRole" to nextRole,
            "challengeIndex" to nextIndex,
            "toniScore" to newToni,
            "ilonaScore" to newIlona,
            "toniStreak" to newToniStreak,
            "ilonaStreak" to newIlonaStreak,
            "level" to newLevel,
            "lastResult" to if(correct)"correct" else "wrong",
            "lastPlayer" to role
        ))
        speak(correctAnswer, if(role=="TONI") Locale.ENGLISH else Locale("es","ES"))
    }

    private fun speak(text:String, locale:Locale) {
        tts.language=locale
        tts.speak(text,TextToSpeech.QUEUE_FLUSH,null,"answer")
    }

    private fun showFinished() {
        question.text="❤️ Partida terminada"
        answers.removeAllViews()
        feedback.text="TONI $toniScore  •  ILONA $ilonaScore\n¡Buen trabajo!"
        next.visibility=View.GONE
        end.visibility=View.GONE
    }

    private fun finishGame() {
        if(room.isNotEmpty()) {
            roomRef().updateChildren(mapOf(
                "active" to false,
                "players/${role.lowercase()}" to false
            ))
        }
        showFinished()
    }

    override fun onInit(statusCode:Int) {
        if(statusCode==TextToSpeech.SUCCESS) tts.language=Locale("es","ES")
    }

    override fun onDestroy() {
        if(room.isNotEmpty() && role.isNotEmpty()) {
            roomRef().child("players").child(role.lowercase()).setValue(false)
        }
        if(::tts.isInitialized) tts.shutdown()
        super.onDestroy()
    }
}
