# TONI ❤️ ILONA — Android

Aplicación Android para jugar juntos a distancia:

- TONI 🇪🇸 aprende inglés 🇬🇧
- ILONA 🇱🇻 aprende español 🇪🇸
- salas online mediante Firebase Realtime Database
- modo infinito ♾️
- puntos, rachas y niveles
- retos de vida cotidiana, viajes, restaurante, pareja y humor
- pronunciación mediante Text-to-Speech

## Firebase

El proyecto ya está asociado a:
`toni-ilona-idiomas`

La app Android usa el paquete:
`com.toniilona.app`

El archivo `app/google-services.json` corresponde a la app Android registrada en Firebase.

## Obtener el APK sin instalar Android Studio

Este proyecto incluye un workflow de GitHub Actions en:
`.github/workflows/build-apk.yml`

Al subir el proyecto a GitHub, Actions compila automáticamente un APK de prueba y lo deja como artefacto descargable.

### Importante

El APK Debug es para instalación directa en los dos móviles. Para una versión final firmada se debe configurar una clave de firma privada.


## Corrección V5
Se eliminó la aplicación explícita del plugin `org.jetbrains.kotlin.android` porque Android Gradle Plugin 9.4.0 incorpora Kotlin integrado.
