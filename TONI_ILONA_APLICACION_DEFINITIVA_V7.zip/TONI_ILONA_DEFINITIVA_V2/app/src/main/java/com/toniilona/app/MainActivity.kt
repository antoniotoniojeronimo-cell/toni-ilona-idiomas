package com.toniilona.app

import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.*
import java.util.Locale
import kotlin.random.Random

data class Challenge(
    val es: String, val en: String,
    val esOptions: List<String>, val enOptions: List<String>,
    val esAnswer: String, val enAnswer: String,
    val mode: String, val level: Int
)

class MainActivity : AppCompatActivity(), TextToSpeech.OnInitListener {
    private val dbUrl = "https://toni-ilona-idiomas-default-rtdb.europe-west1.firebasedatabase.app"
    private lateinit var auth: FirebaseAuth
    private lateinit var db: DatabaseReference
    private lateinit var tts: TextToSpeech

    private var role = ""
    private var room = ""
    private var round = 0
    private var level = 1
    private var streak = 0
    private var toni = 0
    private var ilona = 0
    private var turnRole = "TONI"
    private var toniOnline = false
    private var ilonaOnline = false
    private var current: Challenge? = null
    private var answered = false

    private lateinit var status: TextView
    private lateinit var roomInfo: TextView
    private lateinit var score: TextView
    private lateinit var mode: TextView
    private lateinit var question: TextView
    private lateinit var answers: LinearLayout
    private lateinit var feedback: TextView
    private lateinit var next: Button
    private lateinit var end: Button
    private lateinit var rolePanel: LinearLayout
    private lateinit var roomPanel: LinearLayout
    private lateinit var code: EditText

    private val bank = listOf(
        Challenge("Tengo hambre.","I am hungry.",listOf("Tengo hambre.","Tengo sueño.","Estoy feliz."),listOf("I am hungry.","I am sleepy.","I am happy."),"Tengo hambre.","I am hungry.","Traducción",1),
        Challenge("Buenos días.","Good morning.",listOf("Buenos días.","Buenas noches.","Hasta mañana."),listOf("Good morning.","Good night.","See you tomorrow."),"Buenos días.","Good morning.","Traducción",1),
        Challenge("¿Cómo estás?","How are you?",listOf("¿Cómo estás?","¿Dónde estás?","¿Quién eres?"),listOf("How are you?","Where are you?","Who are you?"),"¿Cómo estás?","How are you?","Conversación",1),
        Challenge("Quiero agua, por favor.","I want water, please.",listOf("Quiero agua, por favor.","Quiero café.","Necesito ayuda."),listOf("I want water, please.","I want coffee.","I need help."),"Quiero agua, por favor.","I want water, please.","Vida cotidiana",1),
        Challenge("No entiendo.","I don't understand.",listOf("No entiendo.","No recuerdo.","No quiero."),listOf("I don't understand.","I don't remember.","I don't want to."),"No entiendo.","I don't understand.","Conversación",1),
        Challenge("¿Dónde está el baño?","Where is the bathroom?",listOf("¿Dónde está el baño?","¿Dónde está el hotel?","¿Cuánto cuesta?"),listOf("Where is the bathroom?","Where is the hotel?","How much is it?"),"¿Dónde está el baño?","Where is the bathroom?","Viaje",1),
        Challenge("Una mesa para dos, por favor.","A table for two, please.",listOf("Una mesa para dos, por favor.","La cuenta, por favor.","Dos cafés, por favor."),listOf("A table for two, please.","The bill, please.","Two coffees, please."),"Una mesa para dos, por favor.","A table for two, please.","Restaurante",1),
        Challenge("Te quiero.","I love you.",listOf("Te quiero.","Te extraño.","Tengo sueño."),listOf("I love you.","I miss you.","I am sleepy."),"Te quiero.","I love you.","❤️ Pareja",1),
        Challenge("¿Quieres ir a la playa conmigo?","Do you want to go to the beach with me?",listOf("¿Quieres ir a la playa conmigo?","¿Quieres comer conmigo?","¿Quieres dormir?"),listOf("Do you want to go to the beach with me?","Do you want to eat with me?","Do you want to sleep?"),"¿Quieres ir a la playa conmigo?","Do you want to go to the beach with me?","❤️ Pareja",2),
        Challenge("El gato lleva mis zapatos.","The cat is wearing my shoes.",listOf("El gato lleva mis zapatos.","El perro come mi pizza.","Mi gato habla inglés."),listOf("The cat is wearing my shoes.","The dog is eating my pizza.","My cat speaks English."),"El gato lleva mis zapatos.","The cat is wearing my shoes.","😂 Absurdo",2),
        Challenge("¿Cuánto cuesta esto?","How much is this?",listOf("¿Cuánto cuesta esto?","¿Qué hora es?","¿Dónde vives?"),listOf("How much is this?","What time is it?","Where do you live?"),"¿Cuánto cuesta esto?","How much is this?","Compras",2),
        Challenge("Estoy cansado, pero feliz.","I am tired, but happy.",listOf("Estoy cansado, pero feliz.","Tengo hambre, pero sueño.","Estoy triste, pero ocupado."),listOf("I am tired, but happy.","I am hungry, but sleepy.","I am sad, but busy."),"Estoy cansado, pero feliz.","I am tired, but happy.","Vida cotidiana",2),
        Challenge("Nos vemos mañana.","See you tomorrow.",listOf("Nos vemos mañana.","Hasta luego.","Buenas tardes."),listOf("See you tomorrow.","See you later.","Good afternoon."),"Nos vemos mañana.","See you tomorrow.","Traducción",2),
        Challenge("¿Puedes ayudarme?","Can you help me?",listOf("¿Puedes ayudarme?","¿Puedes venir mañana?","¿Puedes cocinar?"),listOf("Can you help me?","Can you come tomorrow?","Can you cook?"),"¿Puedes ayudarme?","Can you help me?","Vida cotidiana",2)
    )

    override fun onCreate(state: Bundle?) {
        super.onCreate(state)
        setContentView(R.layout.activity_main)
        bind()
        auth = FirebaseAuth.getInstance()
        db = FirebaseDatabase.getInstance(dbUrl).reference
        tts = TextToSpeech(this, this)
        auth.signInAnonymously().addOnFailureListener { status.text = "⚠️ No se pudo conectar." }
        findViewById<Button>(R.id.toniButton).setOnClickListener { choose("TONI") }
        findViewById<Button>(R.id.ilonaButton).setOnClickListener { choose("ILONA") }
        findViewById<Button>(R.id.createButton).setOnClickListener { createRoom() }
        findViewById<Button>(R.id.joinButton).setOnClickListener { joinRoom() }
        next.setOnClickListener { renderRoom() }
        end.setOnClickListener { finishGame() }
    }

    private fun bind() {
        status=findViewById(R.id.status); roomInfo=findViewById(R.id.roomInfo); score=findViewById(R.id.score)
        mode=findViewById(R.id.category); question=findViewById(R.id.question); answers=findViewById(R.id.answers)
        feedback=findViewById(R.id.feedback); next=findViewById(R.id.nextButton); end=findViewById(R.id.endButton)
        rolePanel=findViewById(R.id.rolePanel); roomPanel=findViewById(R.id.roomPanel); code=findViewById(R.id.roomCode)
    }

    private fun choose(r:String) {
        role=r
        status.text=if(r=="TONI") "TONI 🇪🇸 → inglés 🇬🇧" else "ILONA 🇱🇻 → español 🇪🇸\nLatviski: tu mācies spāņu valodu."
        rolePanel.visibility=View.GONE; roomPanel.visibility=View.VISIBLE; code.visibility=View.VISIBLE
        findViewById<Button>(R.id.createButton).visibility=if(r=="TONI") View.VISIBLE else View.GONE
        findViewById<Button>(R.id.joinButton).visibility=if(r=="ILONA") View.VISIBLE else View.GONE
    }

    private fun newCode()=(1..6).map{"ABCDEFGHJKLMNPQRSTUVWXYZ23456789"[Random.nextInt(32)]}.joinToString("")

    private fun createRoom() {
        if(auth.currentUser==null){status.text="Conectando…";return}
        room=newCode()
        val data=mapOf(
            "active" to true,"turn" to 0,"turnRole" to "TONI",
            "toniScore" to 0,"ilonaScore" to 0,"level" to 1,
            "players" to mapOf("toni" to true,"ilona" to false)
        )
        db.child("rooms").child(room).setValue(data).addOnSuccessListener {
            db.child("rooms").child(room).child("players").child("toni").onDisconnect().setValue(false)
            roomInfo.text="SALA $room"; status.text="Sala creada. Esperando a Ilona…"; listen()
        }.addOnFailureListener { status.text="❌ ${it.message}" }
    }

    private fun joinRoom() {
        room=code.text.toString().trim().uppercase()
        if(room.length!=6){status.text="Escribe un código de 6 caracteres.";return}
        db.child("rooms").child(room).get().addOnSuccessListener {
            if(!it.exists()) status.text="❌ No existe esa sala."
            else {
                db.child("rooms").child(room).child("players").child("ilona").setValue(true).addOnSuccessListener {
                    db.child("rooms").child(room).child("players").child("ilona").onDisconnect().setValue(false)
                    status.text="✅ Unido a $room"; roomInfo.text="SALA $room"; listen()
                }.addOnFailureListener { e -> status.text="❌ ${e.message}" }
            }
        }.addOnFailureListener { status.text="❌ ${it.message}" }
    }

    private fun listen() {
        db.child("rooms").child(room).addValueEventListener(object:ValueEventListener{
            override fun onCancelled(e:DatabaseError){status.text="⚠️ Conexión temporalmente perdida."}
            override fun onDataChange(s:DataSnapshot){
                round=s.child("turn").getValue(Int::class.java)?:0
                turnRole=s.child("turnRole").getValue(String::class.java)?:if(round%2==0)"TONI" else "ILONA"
                toni=s.child("toniScore").getValue(Int::class.java)?:0
                ilona=s.child("ilonaScore").getValue(Int::class.java)?:0
                level=s.child("level").getValue(Int::class.java)?:1
                toniOnline=s.child("players").child("toni").getValue(Boolean::class.java)?:false
                ilonaOnline=s.child("players").child("ilona").getValue(Boolean::class.java)?:false
                updateScore()
                renderRoom()
            }
        })
    }

    private fun updateScore(){
        score.text="TONI 🇬🇧 $toni   •   ILONA 🇪🇸 $ilona\nRonda $round   •   Nivel $level   •   ♾️"
    }

    private fun renderRoom(){
        answered=false; next.visibility=View.GONE; end.visibility=View.VISIBLE
        val connection="TONI ${if(toniOnline)"🟢 conectado" else "⚪ esperando"}   •   ILONA ${if(ilonaOnline)"🟢 conectada" else "⚪ esperando"}"
        roomInfo.text="SALA $room\n$connection"
        if(!toniOnline || !ilonaOnline){
            mode.text="Preparando partida…"
            question.text="❤️ Esperando a que los dos estén conectados"
            answers.removeAllViews(); feedback.text=""
            status.text=if(role=="TONI") "Sala creada. Esperando a Ilona…" else "Conectada. Esperando a Toni…"
            return
        }
        val pool=bank.filter{it.level<=level}.ifEmpty{bank}
        val offset=if(turnRole=="ILONA") 5 else 0
        current=pool[(round+offset)%pool.size]
        val c=current!!
        mode.text="${c.mode}  •  Nivel ${c.level}"
        updateScore()
        if(turnRole!=role){
            question.text="⏳ Turno de ${if(turnRole=="TONI")"TONI 🇪🇸 → 🇬🇧" else "ILONA 🇱🇻 → 🇪🇸"}"
            answers.removeAllViews(); feedback.text="El otro jugador está respondiendo… ❤️"
            return
        }
        question.text=if(role=="TONI") "🇪🇸 ${c.es}\n\n👉 Elige en inglés" else "🇬🇧 ${c.en}\n\n👉 Elige en español"
        answers.removeAllViews(); feedback.text=""
        val opts=if(role=="TONI") c.enOptions else c.esOptions
        opts.shuffled().forEach{value->
            Button(this).apply{ text=value; setOnClickListener{answer(value)}; answers.addView(this) }
        }
        status.text="🎮 ¡Es tu turno!"
    }

    private fun answer(value:String) {
        if(answered || turnRole!=role || !toniOnline || !ilonaOnline)return
        answered=true
        val c=current?:return
        val correct=value==(if(role=="TONI")c.enAnswer else c.esAnswer)
        val newToni=toni + if(correct && role=="TONI") 1 else 0
        val newIlona=ilona + if(correct && role=="ILONA") 1 else 0
        val newLevel=if(correct && (newToni+newIlona)>0 && (newToni+newIlona)%5==0 && level<5) level+1 else level
        streak=if(correct) streak+1 else 0
        val nextRound=round+1
        val nextRole=if(role=="TONI")"ILONA" else "TONI"
        feedback.text=if(correct) "🎉 ¡Correcto! +1\n🔥 Racha $streak" else "💡 La respuesta era:\n${if(role=="TONI")c.enAnswer else c.esAnswer}"
        db.child("rooms").child(room).updateChildren(mapOf(
            "turn" to nextRound,"turnRole" to nextRole,
            "toniScore" to newToni,"ilonaScore" to newIlona,"level" to newLevel
        ))
        speak(if(role=="TONI")c.enAnswer else c.esAnswer, if(role=="TONI")Locale.ENGLISH else Locale("es","ES"))
    }

    private fun speak(text:String, locale:Locale){tts.language=locale;tts.speak(text,TextToSpeech.QUEUE_FLUSH,null,"answer")}

    private fun finishGame(){
        if(room.isNotEmpty()) db.child("rooms").child(room).child("active").setValue(false)
        question.text="❤️ Partida terminada"; answers.removeAllViews()
        feedback.text="TONI $toni  •  ILONA $ilona\n¡Buen trabajo!"; next.visibility=View.GONE; end.visibility=View.GONE
    }

    override fun onInit(status:Int){if(status==TextToSpeech.SUCCESS)tts.language=Locale("es","ES")}
    override fun onDestroy(){if(::tts.isInitialized)tts.shutdown();super.onDestroy()}
}
