plugins {
    id("com.android.application") version "9.4.0" apply false
    id("com.google.gms.google-services") version "4.4.4" apply false
}
