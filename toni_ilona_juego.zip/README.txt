# TONI ❤️ ILONA — juego de idiomas a distancia

## Cómo usarlo
1. Abre `index.html` en un navegador moderno.
2. TONI crea una sala y comparte el código de 6 letras/números con ILONA.
3. ILONA introduce el código y se conecta.
4. Cada uno elige su identidad:
   - TONI: español → inglés
   - ILONA: letón → español
5. El turno y el marcador se sincronizan entre los dos dispositivos.

## Importante
La conexión entre los dos navegadores utiliza PeerJS para establecer la comunicación. Necesitáis Internet.
No hace falta estar en el mismo país ni en la misma red Wi‑Fi.

## Publicarlo gratis
Para usarlo cómodamente desde España y Letonia, sube `index.html` a un alojamiento estático como GitHub Pages, Netlify o Cloudflare Pages. Una vez publicado, ambos abriréis la misma dirección.

La versión incluida empieza en nivel 0 y contiene 10 rondas. Se puede ampliar con más niveles, pronunciación, imágenes, preguntas personalizadas y un modo conversación.
